<?php


function dateMan($receiveData)
{

  // 05.17.2022 17:45:04--gelen  ay gun  yil 

  // 	2022-05-17 17:45:04  - yil ay gun 

  // $receiveData="05.17.2022 17:45:04";

  // 2022-01-03 14:24:11+00
// echo $receiveData;


  $piecesZero = explode("+", $receiveData);
  // print_r($piecesZero);
  // $pieces = explode(" ", $piecesZero[0]);


  return $piecesZero[0];


}



function issuedDate($receiveData)
{

  // 05.17.2022 17:45:04--gelen  ay gun  yil 

  // 	2022-05-17 17:45:04  - yil ay gun 

  // $receiveData="05.17.2022 17:45:04";

  // 2021-07-21


  $pieces = explode(" ", $receiveData);
  $pieces[0]; // piece1
  $pieces[1]; // piece2

  $dateSection = $pieces[0];
  $dateSectionPieces = explode(".", $dateSection);

  return $newDate = $dateSectionPieces[2] . "-" . $dateSectionPieces[0] . "-" . $dateSectionPieces[1];


}


function getGenarateName($n)
{
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $randomString = '';

  for ($i = 0; $i < $n; $i++) {
    $index = rand(0, strlen($characters) - 1);
    $randomString .= $characters[$index];
  }

  return $randomString;
}




function uama_wp_branch_about()
{


  if (!current_user_can('manage_options')) {
    return;
  }


  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1> Ekranlar Bilinmesi Gerekenler</h1>
    <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;">



      <strong>Eklentinin Kullanımı</strong>


    </div>

  </div>



  SELECT * FROM ua_sacrifice_contacts WHERE ((id = 3183)) LIMIT 1;
  SELECT * FROM ua_sacrifice_list WHERE contacts_id=3183 ORDER BY id ASC;
  SELECT * FROM ua_sacrifice_accounting WHERE sacrifice_id IN (5247,5248,5249) ORDER BY id ASC;

  sELECT c.* FROM ua_sacrifice_contacts as c,ua_sacrifice_list as l WHERE l.contacts_id=c.id group by c.id


  // donate and contacts

  SELECT *
  FROM ua_sacrifice_contacts as c JOIN ua_donates as d ON c.id = d.contacts_id;



  CREATE TABLE `ua_information` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contacts_id` bigint DEFAULT '0' UNIQUE,
  `donate_count` int DEFAULT '0',
  `quarban_count` int DEFAULT '0',
  `quarban_money` decimal(15,2) DEFAULT '0.00',
  `donate_money` decimal(15,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


  //select * from ua_donates where contacts_id=4076


  // yalnizca soyut source_type
  select distinct source_type from ua_sacrifice_contacts

  select distinct kaynak from __contact_list5000

  //unique kayitlari bulur

  //SELECT name_lastname, COUNT(*) c FROM ua_sacrifice_contacts GROUP BY name_lastname HAVING c > 1 order by c
  <pre>
          <?php



          // // ----- DONATE LIST --------------
//select * from ua_donates where contacts_id=5272;
//select Sum(amount) AS t  from ua_donates where contacts_id= 5272 ;
        


//           donate_make();
//           quarban_make();
}


function donate_make()
{
  global $wpdb;
  $sql = '  SELECT * FROM ua_sacrifice_contacts as c JOIN ua_donates as d ON c.id = d.contacts_id ';
  $list = $wpdb->get_results($wpdb->prepare($sql));
  foreach ($list as $row):

    $sql2 = " SELECT id,contacts_id,donate_count,quarban_count,quarban_money,donate_money  from ua_information where contacts_id=$row->contacts_id  GROUP BY id";
    echo "<br>";
    $map = $wpdb->get_row($wpdb->prepare($sql2));

    echo $sql22 = "select count(id) as c  from ua_donates where contacts_id= $row->contacts_id ";

    echo $donate_count = ($wpdb->get_var($sql22));

    echo $sql23 = "select Sum(amount) AS t  from ua_donates where contacts_id= $row->contacts_id ";

    $donate_money = $wpdb->get_var($sql23);

    $wpdb->insert(
      'ua_information',
      array(
        'contacts_id' => $row->contacts_id,
        'donate_count' => $donate_count,
        'quarban_count' => 0,
        'quarban_money' => 0,
        'donate_money' => $donate_money,
      ),
    );
  endforeach;

}


function quarban_make()
{
  global $wpdb;
  // /----------- qurbani data migrate 
  $sql = '  SELECT * FROM ua_sacrifice_contacts as c JOIN ua_sacrifice_list as l ON c.id =l.contacts_id ';
  $list = $wpdb->get_results($wpdb->prepare($sql));
  foreach ($list as $row):

    $sql2 = " SELECT id,contacts_id,donate_count,quarban_count,quarban_money,donate_money  from ua_information where contacts_id=$row->contacts_id  GROUP BY id";
    echo "<br>";
    $map = $wpdb->get_row($wpdb->prepare($sql2));

    echo $sql22 = "select count(id) as c  from ua_sacrifice_list where contacts_id= $row->contacts_id ";
    echo "<br>";
    echo $quarban_count = ($wpdb->get_var($sql22));
    echo "<br>";
    echo $sql23 = "select sum(sacrifice_price) AS t  from ua_sacrifice_list where contacts_id= $row->contacts_id ";

    $quarban_money = $wpdb->get_var($sql23);

    $contacts_id_check = $map->contacts_id;
    if ($contacts_id_check == $row->contacts_id) {
      $wpdb->update(
        'ua_information',
        array(
          'quarban_count' => $quarban_count,
          'quarban_money' => $quarban_money,

        ),
        array('contacts_id' => $row->contacts_id)
      );
    } else {
      $wpdb->insert(
        'ua_information',
        array(
          'contacts_id' => $row->contacts_id,
          // 'donate_count' =>0,
          // 'donate_money' =>  0,
          'quarban_count' => $quarban_count,
          'quarban_money' => $quarban_money,

        ),
      );
    }
  endforeach;

}