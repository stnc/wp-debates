=== Customizer Search ===
Contributors: brainstormforce, Nikschavan
Donate link: https://www.paypal.me/BrainstormForce
Tags: customizer, search
Requires at least: 4.6
Tested up to: 6.5
Stable tag: 1.1.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Search for settings in customizer.

== Description ==

Using a theme powered by the WordPress Customizer? Then you will love this plugin. Save the time and frustration finding options. Simply search for the setting you're looking for and get there instantly.

Works with all WordPress themes.

https://www.youtube.com/watch?v=IBFfap_vGzg

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/customizer-search` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Search field will appear when in the customizer.

== Changelog ==

= 1.1.6 =
- Fix: Admin notice CSS console error in admin area.

= 1.1.5 =
- Fix: Fixed compatibility with other plugins with respect to the admin notice.

= 1.1.4 =
- New: Users can now share non-personal usage data to help us test and develop better products. ( https://store.brainstormforce.com/usage-tracking/?utm_source=wp_dashboard&utm_medium=general_settings&utm_campaign=usage_tracking )

= 1.1.3 =
- Setup plugin translations through https://translate.wordpress.org/projects/wp-plugins/customizer-search/.

= 1.1.2 =
- Change the background color highlight in the searched results.

= 1.1.1 =
- Highlight the characters that are matched in the results.
- Auto focus the search input when the search icon is clicked.

= 1.1.0 =
- Rewrite the search logic to improve the search results.
- The search results are direct links to the customizer panel where the searched setting resides, This improves the required clicks to get to the search setting from old version.

= 1.0.0 =
- Initial Release
