<?php

function dateMan($receiveData)
{

  // 05.17.2022 17:45:04--gelen  ay gun  yil 

  // return 	2022-05-17 17:45:04  - yil ay gun 

  // $receiveData="05.17.2022 17:45:04";




  $pieces = explode(" ", $receiveData);
  $pieces[0]; // piece1
  $pieces[1]; // piece2

  $dateSection = $pieces[0];
  $dateSectionPieces = explode(".", $dateSection);

  return $newDate = $dateSectionPieces[2] . "-" . $dateSectionPieces[0] . "-" . $dateSectionPieces[1] . " " . $pieces[1];


}

function uama_wp_branch_about()
{


  if (!current_user_can('manage_options')) {
    return;
  }


  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1> Ekranlar Bilinmesi Gerekenler</h1>
    <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;">

      qurbani
      stripe
      ozel_form
      iletisim_formu bundan 227 tane var SELECT count(*) as count from __contact_list5000 where kaynak="iletisim_formu"
      by_hand

      bu listeye gore yeniden filtrelenmeli ve ona gore silinmeli qurbani500 ve donate e gore de filtreleme yapilmasi
      lazim



      ---- bu liste select distinct source_type from ua_sacrifice_contacts icindir
      liveDonor
      sacrifice
      donate
      qurbani500
      qurbani
      stripe
      ozel_form
      by_hand

      __kurbanlik_bilgileri_500 qurbani500



      <strong>Eklentinin Kullanımı</strong>


    </div>

  </div>
  <pre>
  <?php
  global $wpdb;








  ////DELETE FROM ua_sacrifice_contacts WHERE  source_type = "iletisim_formu"

  // $sql = 'SELECT * from   __contact_list5000 where  kaynak="iletisim_formu"  '  ;
// $list = $wpdb->get_results($wpdb->prepare($sql));    
// echo       $wpdb->last_query ;
// foreach ($list as $row) : 

  // echo "<br>";


  // echo       $wpdb->last_query ;




  //     // $wpdb->insert('ua_sacrifice_contacts', array(
//     //   'name_lastname' => $row->ad_soyad,
//     //   'user_id' => 46,
//     //   'phone' => $row->telefon,
//     //   'email' => $row->eposta,
//     //   'status' => 0,
//     //   'reference_user_id' => 0,
//     //   'currency_type' => 2,
//     //   'origins' => 0,
//     //   'affinity_type' => 0,
//     //   'source_type' => "iletisim_formu",
//     //   'created_at' => dateMan($row->tarih),
//     //   'updated_at' => dateMan($row->tarih)
//     // )
//     // );


  //     echo       $wpdb->last_query ;


  // endforeach ;


  //SELECT id from   ua_sacrifice_contacts where is_duplicate=1  and is_donate=1 and is_kurban=1




  //__contact_list5000 tablosundan kaynak iletisim_formu yazanlari aktar 
// ---
//ua_sacrifice_contacts de duplicate olanlar ise 


  // disctint in tersi seklinde calisir -- bu duplicate kayirtlari gosterir 
//SELECT name_lastname, COUNT(*) c FROm ua_sacrifice_contacts  GROUP BY name_lastname HAVING c > 1 order by c desc

  // ama en onemlisi donate 
  $i = 0;

//select * from ua_sacrifice_contacts where is_duplicate and is_kurban=0 and is_donate=0 order by name_lastname

  $sql = 'select * from ua_sacrifice_contacts where is_duplicate=1  order by name_lastname ';
  $list = $wpdb->get_results($wpdb->prepare($sql));
  foreach ($list as $row):
    $i++;

    // if ($row->id!=$row->replace_id){
    //   $wpdb->delete( 'ua_sacrifice_contacts', array( 'id' => $row->id ) );
    // }
    
  endforeach;


  echo $i;




}
