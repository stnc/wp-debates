<?php
$sonuc = '<div class="row recent-events">
<div class="col-md-12">
    <span class="header"> Recent Events</span>
</div>

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz7_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">28</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-7/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 7</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-7/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz6_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">27</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-6/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 6</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-6/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz4_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">26</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-4-and-5-/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: Second half of 4 and 5 </a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-4-and-5-/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz3_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">25</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz3-and-first-half-of-4/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:3 and first half of 4</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz3-and-first-half-of-4/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz2_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">24</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz2-2/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:2</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz2-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz1_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">23</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz1-2/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:1</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz1-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz30.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">01</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz30/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:30</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz30/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz29.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">30</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz29/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:29</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz29/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz28.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">29</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz28/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:28</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz28/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz27.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">28</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz27/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:27</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz27/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz26.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">27</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz26/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:26</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz26/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz25.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">26</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz25/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:25</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz25/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz24.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">25</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz24/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:24</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz24/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz23.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">24</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz23/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:23</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz23/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz22.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">23</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz22/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:22</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz22/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz21.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">22</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz21/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:21</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz21/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz20.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">21</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz20/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:20</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz20/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz19.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">20</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz19/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:19</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz19/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz18.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">19</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz18/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:18</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz18/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz17.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">18</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz17/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:17</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz17/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz16.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">17</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:15 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz16/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:16</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz16/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz15.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">16</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz15/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:15</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz15/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz14.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">15</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz14/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:14</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz14/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz13.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">14</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz13/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:13</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz13/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz12.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">13</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz12/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:12</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz12/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz11.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">12</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz11/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:11</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz11/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz10.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">11</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz10/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:10</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz10/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz9.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">10</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz9/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:9</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz9/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz8.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">09</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz8/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:8</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz8/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz7.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">08</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz7/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:7</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz7/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz6.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">07</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz6/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:6</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz6/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">02</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:45 AM-5:15 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2022-ramadan/">Muqabalah 2022 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz1/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:1</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>"The UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:45 (AM) Eastern time....</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz1/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Islamic_Values_Seminars_01-event-cover.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">18</span>
                <span class="event-date-month">Dec</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 PM-8:30 PM (EST)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/online-parent-seminars/">Online Parent Seminars</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-parents-islamic-values-seminars-1-2021-2022/">The UAMA Parent;;s Islamic Values Seminars - 1 (2021-2022)</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Topics: 


The Virtous Of İlm
Daily Life of Our Talebes
Daily Life Guide - Fazilet Calender</p>
          
            <a href="https://uama.us/en/the-uama-parents-islamic-values-seminars-1-2021-2022/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz29.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">08</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz29-30/">The UAMA Online Muqabalah Program (PST) Juz:29-30</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz29-30/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-29.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">08</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz29-30/">The UAMA Online Muqabalah Program (EST) Juz:29-30</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz29-30/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz27.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">07</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz27-28/">The UAMA Online Muqabalah Program (PST) Juz:27-28</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz27-28/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-27.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">07</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz27-28/">The UAMA Online Muqabalah Program (EST) Juz:27-28</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz27-28/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">06</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz26-27/">The UAMA Online Muqabalah Program (PST) Juz:26-27</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz26-27/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-26.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">06</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz26-27/">The UAMA Online Muqabalah Program (EST) Juz:26-27</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz26-27/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz25.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">05</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz25-26/">The UAMA Online Muqabalah Program (PST) Juz:25-26</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz25-26/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-25.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">05</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz25-26/">The UAMA Online Muqabalah Program (EST) Juz:25-26</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz25-26/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz24.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">04</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz24-25/">The UAMA Online Muqabalah Program (PST) Juz:24-25</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz24-25/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-24.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">04</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz24-25/">The UAMA Online Muqabalah Program (EST) Juz:24-25</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz24-25/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz22.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">03</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz22-23/">The UAMA Online Muqabalah Program (PST) Juz:22-23</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz22-23/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-22_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">03</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz22-23/">The UAMA Online Muqabalah Program (EST) Juz:22-23</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz22-23/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz21.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">02</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz21-22/">The UAMA Online Muqabalah Program (PST) Juz:21-22</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz21-22/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-22.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">02</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz21-22/">The UAMA Online Muqabalah Program (EST) Juz:21-22</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz21-22/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">01</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz20-21/">The UAMA Online Muqabalah Program (PST) Juz:20-21</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz20-21/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-20.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">01</span>
                <span class="event-date-month">May</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz19-20/">The UAMA Online Muqabalah Program (EST) Juz:19-20</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz19-20/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz19-20.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">30</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz19-20/">The UAMA Online Muqabalah Program (PST) Juz:19-20</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz19-20/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz17-18_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">29</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz17-18/">The UAMA Online Muqabalah Program (PST) Juz:17-18</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz17-18/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-17-18.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">29</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz17-18/">The UAMA Online Muqabalah Program (EST) Juz:17-18</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz17-18/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz16_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">28</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz16/">The UAMA Online Muqabalah Program (PST) Juz:16</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz16/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-16_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">28</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz16/">The UAMA Online Muqabalah Program (EST) Juz:16</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz16/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz15.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">27</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz14-2/">The UAMA Online Muqabalah Program (PST) Juz:14</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz14-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-15.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">27</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz15/">The UAMA Online Muqabalah Program (EST) Juz:15</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz15/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz14_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">26</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:00 AM-7:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz14/">The UAMA Online Muqabalah Program (PST) Juz:14</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00 Pacific time. Again on...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz14/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-14.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">26</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:00 AM-4:45 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz14/">The UAMA Online Muqabalah Program (EST) Juz:14</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at 04:00(AM) Eastern time. Again...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz14/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz13.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">25</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz13/">The UAMA Online Muqabalah Program (PST) Juz:13</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz13/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-13.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">25</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz13/">The UAMA Online Muqabalah Program (EST) Juz:13</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz13/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz12.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">24</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz12/">The UAMA Online Muqabalah Program (PST) Juz:12</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz12/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-12.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">24</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz12/">The UAMA Online Muqabalah Program (EST) Juz:12</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz12/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz11.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">23</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz11/">The UAMA Online Muqabalah Program (PST) Juz:11</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz11/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-11.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">23</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz11/">The UAMA Online Muqabalah Program (EST) Juz:11</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz11/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz10.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">22</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz10/">The UAMA Online Muqabalah Program (PST) Juz:10</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz10/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-10.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">22</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz10/">The UAMA Online Muqabalah Program (EST) Juz:10</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz10/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_10.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">22</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-10-obedience-and-submissiveness-the-uama-online-ramadan-reminders/">Day 10 - Obedience and Submissiveness</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-10-obedience-and-submissiveness-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz09.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">21</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz9/">The UAMA Online Muqabalah Program (PST) Juz:9</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz9/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-09.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">21</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz9/">The UAMA Online Muqabalah Program (EST) Juz:9</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz9/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_7.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">21</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-09-prayer-salah-and-tarawih-the-uama-online-ramadan-reminders/">Day 09 - Prayer, Salah and Tarawih</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-09-prayer-salah-and-tarawih-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz08.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">20</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz8/">The UAMA Online Muqabalah Program (PST) Juz:8</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz8/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-08.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">20</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz8/">The UAMA Online Muqabalah Program (EST) Juz:8</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz8/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_8.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">20</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-08-cleanliness-in-islam-the-uama-online-ramadan-reminders/">Day 08 - Cleanliness in Islam</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-08-cleanliness-in-islam-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz07.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">19</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz7/">The UAMA Online Muqabalah Program (PST) Juz:7</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz7/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-07.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">19</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz7/">The UAMA Online Muqabalah Program (EST) Juz:7</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz7/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_9.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">19</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-07-welcoming-the-month-of-ramadan-the-uama-online-ramadan-reminders/">Day 07 - Welcoming The Month of Ramadan</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-07-welcoming-the-month-of-ramadan-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz06.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">18</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz6/">The UAMA Online Muqabalah Program (PST) Juz:6</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz6/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-06.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">18</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz6/">The UAMA Online Muqabalah Program (EST) Juz:6</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz6/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_6.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">18</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-05-reading-quran-and-the-virtues-of-knowledge-the-uama-online-ramadan-reminders/">Day 05 - Reading Qur;;an and The Virtues of Knowledge</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-05-reading-quran-and-the-virtues-of-knowledge-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz05.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">17</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz5/">The UAMA Online Muqabalah Program (PST) Juz:5</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz5/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-05.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">17</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz5/">The UAMA Online Muqabalah Program (EST) Juz:5</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz5/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_4.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">17</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-05-repentance-tawba-and-mercy-rahmah-the-uama-online-ramadan-reminders/">Day 05 - Repentance (Tawba) and Mercy (Rahmah)</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-05-repentance-tawba-and-mercy-rahmah-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz04.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">16</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz4/">The UAMA Online Muqabalah Program (PST) Juz:4</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz4/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-04.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">16</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz4/">The UAMA Online Muqabalah Program (EST) Juz:4</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz4/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_5.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">16</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-04-zakat-in-the-quran-the-uama-online-ramadan-reminders/">Day 04 - Zakat in The Qur’an || The UAMA Online Ramadan Reminders</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-04-zakat-in-the-quran-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz03.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">15</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz3/">The UAMA Online Muqabalah Program (PST) Juz:3</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz3/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-03.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">15</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz3/">The UAMA Online Muqabalah Program (EST) Juz:3</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz3/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_3.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">15</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-03-rewards-of-a-person-who-prays-consistently-the-uama-online-ramadan-reminders/">Day 03 - Rewards Of a Person Who Prays Consistently</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-03-rewards-of-a-person-who-prays-consistently-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz02.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">14</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz2/">The UAMA Online Muqabalah Program (PST) Juz:2</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-02.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">14</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz2/">The UAMA Online Muqabalah Program (EST) Juz:2</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">14</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-02-fasting-sawm-the-uama-online-ramadan-reminders/">Day 02 - Fasting (Sawm)</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April, and will be every day during Ramadan Sharif at 8:30...</p>
          
            <a href="https://uama.us/en/day-02-fasting-sawm-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz01.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">13</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">7:30 AM-8:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-pst/">Muqabalah (PST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz1/">The UAMA Online Muqabalah Program (PST) Juz:1</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-pst-juz1/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Ramadan_Reminders_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">13</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:00 PM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/ramadan-reminders-2021/">Ramadan Reminders 2021</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/day-01-the-virtue-of-ramadan-i-shareef-and-holy-quran-the-uama-online-ramadan-reminders/">Day 01 - The Virtue of Ramadan-i Shareef and Holy Quran</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Follow "The UAMA Online Ramadan Reminders 2021". It;;s started on 13rd&nbsp;April and will be every day during Ramadan Sharif at 8:30 pm.</p>
          
            <a href="https://uama.us/en/day-01-the-virtue-of-ramadan-i-shareef-and-holy-quran-the-uama-online-ramadan-reminders/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Muqabalah--Juzz-01.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">13</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-est/">Muqabalah (EST)</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz1/">The UAMA Online Muqabalah Program (EST) Juz:1</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website.&nbsp;</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-est-juz1/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Mirac_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">10</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:45 PM (EST)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/online-parent-seminars/">Online Parent Seminars</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/seminar-5/">The UAMA Parent;;s Islamic Values Seminars - 5</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Our speaker is on the live broadcast we will perform as part of "The UAMA Parent;;s Islamic Values Seminars". They will talk about...</p>
          
            <a href="https://uama.us/en/seminar-5/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Islamic_Values_Seminars_4.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">06</span>
                <span class="event-date-month">Feb</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:45 PM (EST)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/online-parent-seminars/">Online Parent Seminars</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-parents-islamic-values-seminars-4/">The UAMA Parent;;s Islamic Values Seminars - 4</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Our speaker is on the live broadcast we will perform as part of "The UAMA Parent;;s Islamic Values Seminars". They will talk about...</p>
          
            <a href="https://uama.us/en/the-uama-parents-islamic-values-seminars-4/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Islamic_Values_Seminars_3.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">09</span>
                <span class="event-date-month">Jan</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:45 PM (EST)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/online-parent-seminars/">Online Parent Seminars</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-parents-islamic-values-seminars-3/">The UAMA Parent;;s Islamic Values Seminars - 3</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Our speakers is on the live broadcast we will perform as part of "The UAMA Parent;;s Islamic Values Seminars". They will talk about...</p>
          
            <a href="https://uama.us/en/the-uama-parents-islamic-values-seminars-3/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Islamic_Values_Seminars_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">19</span>
                <span class="event-date-month">Dec</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:45 PM (EST)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/online-parent-seminars/">Online Parent Seminars</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-parents-islamic-values-seminars-2-2/">The UAMA Parent;;s Islamic Values Seminars - 2</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>Our speakers is on the live broadcast we will perform as part of "The UAMA Parent;;s Islamic Values Seminars". They will talk about...</p>
          
            <a href="https://uama.us/en/the-uama-parents-islamic-values-seminars-2-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/Islamic_Values_Seminars_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">05</span>
                <span class="event-date-month">Dec</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">8:30 PM-9:45 PM (EST)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/online-parent-seminars/">Online Parent Seminars</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-parents-islamic-values-seminars-1/">The UAMA Parent;;s Islamic Values Seminars - 1</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The 2020-2021 schedule of&nbsp;"The UAMA Parent;;s Islamic Values Seminars"&nbsp;series is given on our&nbsp;website. From time to time,...</p>
          
            <a href="https://uama.us/en/the-uama-parents-islamic-values-seminars-1/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

</div>';
