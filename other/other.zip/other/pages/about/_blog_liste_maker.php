<?php
function uama_wp_branch_about(){


    if ( ! current_user_can( 'manage_options' ) ) {  return; }
    

      ?>
      <!-- Our admin page content should all be inside .wrap -->
      <div class="wrap">
        <!-- Print the page title -->
        <h1> Ekranlar Bilinmesi Gerekenler</h1>
        <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;"
    >


    
         <strong>Eklentinin Kullanımı</strong>

  
         </div>
      </div>
    <?php



    //https://code.tutsplus.com/writing-custom-queries-in-wordpress--wp-25510t

global $wpdb;

// $current_user = wp_get_current_user();

// $uid = $current_user->ID;

// $fname = $current_user->first_name . " " . $current_user->last_name;

// $email = $current_user->user_email;

// $studentTable = $wpdb->prefix.'um_metadata';

// $sql = 'SELECT * FROM user2'  ;
// $buildingsList = $wpdb->get_results($sql);    
// foreach ($buildingsList as $building) : 
//     echo $building->first_name ;
//     echo '<br>';

//     $post_id = wp_insert_post(array (
//       'post_type' => 'uama_staff',
//       'post_title' => $building->first_name." ".$building->last_name,
//       'post_content' => "Staff Info",
//       'post_status' => 'publish',
//       'visibility' => 'provate',
//       'comment_status' => 'closed',
//       'ping_status' => 'closed',
//       'meta_input' => array(
//          'uama_wp_staff_Metabox_email' => $building->email,
//          'uama_wp_staff_Metabox_name_lastname' =>  $building->first_name." ".$building->last_name,
//          'uama_wp_staff_Metabox_name' =>  $building->first_name,
//          'uama_wp_staff_Metabox_lastname' =>  $building->last_name,
//          'uama_wp_staff_Metabox_password' =>  $building->password,
//          'uama_wp_staff_Metabox_phone1' =>  $building->phone,
//          'uama_wp_staff_Metabox_username' =>  $building-> username ,
//          'uama_wp_staff_Metabox_website' =>  "",
//        ),
//    ));
//  endforeach ;

// die;





 
 
include ("data_blog.php");
     



echo '<pre>';
  $content = regexlink1( $sonuc );
  $img =regexImg1($sonuc);
 print_r(  $content);

 $view = regexview1($sonuc);
 $tarih= regexTarih1($sonuc);
 $img= regexImg1($sonuc);
 $exc= regexExceprt1($sonuc);
 $cat= regexCat1($sonuc);


  foreach ($content as $key => $value) {
echo $key;
  echo $img[$key ][1]; 
  echo "<br>";
  echo $value[1];
  echo "<br>";

 $img1= strip_tags($img[$key ][1]);
//  $img1 = str_replace(' ', '',  $img1);
 $img1 = trim($img1);

 $tarih1= strip_tags($tarih[$key ][0]);
//  $tarih1 = str_replace(' ', '',  $tarih1);
 $tarih1 = trim($tarih1);

 $cat1= strip_tags($cat[$key ][0]);
//  $cat1 = str_replace(' ', '',  $cat1);
 $cat1 = trim($cat1);


 $view1= strip_tags($view[$key ][0]);
 $view1 = str_replace('>', '',  $view1);
 $view1 = str_replace('Views', '',  $view1);
 $view1 = trim($view1);


 $exc1= strip_tags($exc[$key ][0]);
//  $exc1 = str_replace(' ', '',  $exc1);
 $exc1 = trim($exc1);

    $success =   $wpdb->insert(
      "aktar_blog_list",
      array(
          'sayfa' =>  $value[1],
          'durum' =>   0,
          'resim' =>   $img1 ,
          'tarih' =>     $tarih1,
          'kategori' =>    $cat1,
          'view' =>     $view1,
          'excerpt' =>     $exc1,
      ),
  );
}


//  $sql = 'SELECT * FROM aktar_blog_list'  ;
//  $buildingsList = $wpdb->get_results($sql);
//  foreach ($buildingsList as $building) : 
//      echo "https://uama.us//d_genel/".$building->picture ;
//      echo '<br>';
 
//      $post_id = wp_insert_post(array (
//        'post_type' => 'branch',
//        'post_title' => $building->title,
//        'post_content' => $building->html,
    
//        'post_status' => 'publish',
//        'visibility' => 'provate',
//        'comment_status' => 'closed',
//        'ping_status' => 'closed',
//        'meta_input' => array(
//           'uama_wp_branch_Metabox_branch_name' =>  $building->title,
//           'uama_wp_branch_Metabox_color_code' =>  "black",
//           'uama_wp_branch_Metabox_google_map' => "",
//           'uama_wp_branch_Metabox_branch_code' => $building->branch_code,
//         ),
//     ));
 
 
//   endforeach ;




}




function regexCat1($sonuc)
{

  $re = '/(?<=<span class="category">)(.|\n)*?(?=<\/span)/mu';

    preg_match_all($re, $sonuc, $matches, PREG_SET_ORDER, 0);
    // print_r(  $matches[0]);
    // Print the entire match result
    return $matches;
}


function regexExceprt1($sonuc)
{

  $re = '/(?<=<p class="mt-3">)(.|\n)*?(?=<\/p>)/mu';

    preg_match_all($re, $sonuc, $matches, PREG_SET_ORDER, 0);
    // print_r(  $matches[0]);
    // Print the entire match result
    return $matches;
}

function regexImg1($str)
{
  $re = '/src="(.*?)"/m';
  preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);

   // print_r(  $matches[0]);
   // Print the entire match result
   // $info = parse_url($match);
   // print_r ( $info);
   return $matches;
}

function regexImgOLD($sonuc)
{
    $re = '/<img[^>]*?src\s*=\s*[""\']?([^\'"" >]+?)[ \'""][^>]*?>/m';
    preg_match_all($re, $sonuc, $matches, PREG_SET_ORDER, 0);
    // print_r(  $matches[0]);
    // Print the entire match result
    return $matches;
}

function regexview1($sonuc)
{

  $re = '/(?<=i class="fa fa-eye")(.|\n)*?(?=<\/a>)/mu';

    preg_match_all($re, $sonuc, $matches, PREG_SET_ORDER, 0);
    // print_r(  $matches[0]);
    // Print the entire match result
    return $matches;
}


function regexTarih1($sonuc)
{

    $re = '/(?<=<span class="date">)(.|\n)*?(?=<\/span>)/mu';

    preg_match_all($re, $sonuc, $matches, PREG_SET_ORDER, 0);
    // print_r(  $matches[0]);
    // Print the entire match result
    return $matches;
}


function regexlink1($str)
{

    // $url = preg_match_all('/<a  class="entry-date" rel="bookmark" href="(.+)">/', $sonuc, $match, PREG_SET_ORDER, 0);

   $re = '/href="(.*?)" rel="bookmark" class="entry-date"/m';
   preg_match_all($re, $str, $matches, PREG_SET_ORDER, 0);

    // print_r(  $matches[0]);
    // Print the entire match result
    // $info = parse_url($match);
    // print_r ( $info);
    return $matches;

}