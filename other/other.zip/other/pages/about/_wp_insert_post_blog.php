<?php
function uama_wp_branch_about()
{


  if (!current_user_can('manage_options')) {
    return;
  }


  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1> Ekranlar Bilinmesi Gerekenler</h1>
    <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;">



      <strong>Eklentinin Kullanımı</strong>


    </div>
  </div>
  <?php



  //https://code.tutsplus.com/writing-custom-queries-in-wordpress--wp-25510t

//cat 
//https://www.hostinger.com/tutorials/wp-insert-post
//https://wordpress.stackexchange.com/questions/111962/how-to-insert-category-and-subcategory-using-wp-insert-post-function


  global $wpdb;

  // $current_user = wp_get_current_user();

  // $uid = $current_user->ID;

  // $fname = $current_user->first_name . " " . $current_user->last_name;

  // $email = $current_user->user_email;

  // $studentTable = $wpdb->prefix.'um_metadata';





  // $sql = 'SELECT * FROM aktar_blog_list where durum=0 limit 1;';
  $sql = 'SELECT * FROM aktar_blog_list where kategori="Social Life" and wp_aktarildimi=0 ';
  $content = $wpdb->get_results($sql);
  foreach ($content as $key => $value):

    $view = str_replace(',', '',   $value->view);
          $post_id = wp_insert_post(array (
      'post_type' => 'post',
      'post_title' => $value->title,
      'post_content' => $value->content,
      'post_excerpt' => $value->excerpt,
      'post_date'     => date("Y-m-d H:i:s", strtotime( $value->tarih)),
      'post_status' => 'publish',
      'comment_status' => 'closed',
      'ping_status' => 'closed',
      'meta_input' => array(
         'post_view' =>     $view ,
         'uama_post_event_metabox_page_view' =>    $view ,
         'uama_post_event_metabox_time' =>$value->tarih,
         'layout_on' =>  1,
         'subheader_on' =>  1,
         'layout_page' =>  "no_sidebar",
       ),
      ));


      set_post_thumbnail( $post_id, $value->wp_media_id );


      $post_categories = array(140); // Category IDs to assign to the post
      wp_set_post_categories($post_id, $post_categories); // Set post categories


         $wpdb->update(
         'aktar_blog_list',
        array(
          'wp_post_id' => $post_id,
          'wp_aktarildimi' =>   1,
        ),
        array('id' =>$value->id )
        );


//TODO : ve tarih kaldi 


    //  $wpdb->update(
    //      'aktar_blog_list',
    //     array(
    //          'resim_indimi' =>  1,
    //          'wp_media_id' =>   $wp_media_id,
    //     ),
    //     array('id' =>$value->id )
    //     );



  endforeach;




}
