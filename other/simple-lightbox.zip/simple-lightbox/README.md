Simple Lightbox
===============

The highly customizable lightbox for WordPress

http://archetyped.com/tools/simple-lightbox/

## Support
Found a bug or otherwise experiencing an issue with Simple Lightbox?  [Report the issue here][issue-report]

[issue-report]: https://github.com/archetyped/simple-lightbox/wiki/Reporting-Issues "Report an issue"
