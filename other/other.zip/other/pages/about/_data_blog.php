<?php

$sonuc = '<div class="row xs-mb-50">
					
					
            
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/what-is-the-day-of-ashura/" rel="bookmark" class="entry-date">
                                          17 Jul 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/what-is-the-day-of-ashura/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/what-is-the-day-of-ashura/">What is the Day of Ashura?</a>
                              </h4>
                              <p class="mt-3">Whoever spends the Day of Ashura, namely the 10th of Muharram, in ibAdah (Acts of worship) and in discharging sadaqah (charity) will be blessed by Allah SubhAnahu with plenty of thawAb (rewards).
Abū Bakr al Warraq (rahmatullāhi ‘alayhi), a walī (friend) of Allāh said:
“Every good deed in Rajab Sharīf is recorded as ten good deeds, in Sha‘bān Sharīf, as seventy, and in the Ramaḍān as one thousand.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/what-is-the-day-of-ashura/">990 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_27.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-excellence-of-raman-sharf/" rel="bookmark" class="entry-date">
                                          09 Mar 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-excellence-of-raman-sharf/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-excellence-of-raman-sharf/">THE EXCELLENCE OF RAMAḌĀN SHARĪF</a>
                              </h4>
                              <p class="mt-3">Rasūlullāh (sallallāhu ‘alayhi wa sallam) said:
“Whoever attends a gathering of dhikr (remembrance of Allāh), Allāh Ta‘ālā writes one thawāb (merit) of ibādah for each step he takes (while going to and coming from that gathering) and he will be together with me under the Arsh al-Ā’la (The Great Throne) on the Day of Qiyāmah.” “Whoever continues to attend the congregation (of salāh) in the month of Ramaḍān, Allāh Ta‘ālā gives him one city made of light (in paradise) for every rak‘ah he has performed.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-excellence-of-raman-sharf/">1,787 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_26.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-merits-of-the-night-of-barah/" rel="bookmark" class="entry-date">
                                          02 Mar 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-merits-of-the-night-of-barah/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-merits-of-the-night-of-barah/">THE MERITS OF THE NIGHT OF BARĀ’AH</a>
                              </h4>
                              <p class="mt-3">Rasūlullāh (sallallāhu alayhi wa sallam) said: “Allāh Ta‘ālā manifests (with His Mercy) in the night of the half of Sha‘bān (Sharif) and forgives all His creation, except the one who associates partners with Him or the one who has hatred in his heart (against a Muslim).” (Munāwī Faydh al-Qadīr)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-merits-of-the-night-of-barah/">1,704 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_25.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/shabn-sharf/" rel="bookmark" class="entry-date">
                                          23 Feb 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/shabn-sharf/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/shabn-sharf/">SHA‘BĀN SHARĪF</a>
                              </h4>
                              <p class="mt-3">A mu’min should constantly strive to attain closeness to his Rabb through giving sadaqah, keeping (nāfilah) fast, Tahajjud Salāh and many other forms of ibādah (acts of worship). They should make more efforts especially during the Three Blessed Months (Rajab, Sha‘bān and Ramaḍān).
Abū Bakr al Warraq (rahmatullāhi ‘alayhi), a walī (friend) of Allāh said:
“Every good deed in Rajab Sharīf is recorded as ten good deeds, in Sha‘bān Sharīf, as seventy, and in the Ramaḍān as one thousand.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/shabn-sharf/">1,234 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_24.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-miracle-of-mirj/" rel="bookmark" class="entry-date">
                                          17 Feb 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-miracle-of-mirj/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-miracle-of-mirj/">THE MIRACLE OF MI‘RĀJ</a>
                              </h4>
                              <p class="mt-3">Rasūlullāh (sallallāhu ‘alayhi wa sallam) was taken with Buraq from Masjid al-Haram to Masjid al-Aqsā on the 27th night of Rajab, one and a half years before the Hijrah. Then, with the Mī‘raj (staircase) brought, he was taken from the big rock in Masjid al-Aqsā to the lower heaven. He met with the prophets in each heaven. After greeting and talking to them, he reached Sidrah al-Muntaha. From there, he got on Rafraf and was blessed with the divine presence. He was shown many wonders from Allāh Ta‘ālā’s kingdom</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-miracle-of-mirj/">607 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_23.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-greatest-form-of-repentance-tasbh-salh/" rel="bookmark" class="entry-date">
                                          02 Feb 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-greatest-form-of-repentance-tasbh-salh/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-greatest-form-of-repentance-tasbh-salh/">THE GREATEST FORM OF REPENTANCE: TASBĪH SALĀH</a>
                              </h4>
                              <p class="mt-3">Tasbīh Salāh is the highest form of Tawbah (repentance) and Istighfār (asking for forgiveness) that is carried out with the entire body.
Rasūlullāh (sallallāhu ‘alayhi wa sallam) once said to his uncle Abbās (raḍiyallāhu‘anhu) concerning TasbīhSalāh: “O, uncle! Let me gift you by describing to you something which will erase 10 types of sin, when you do so, the first and last, new and old, intentional or unintentional, major or minor, secret or open of your sins will be forgiven. You pray four rak‘ah salāh. If you can, pray this salāh every day. If you cannot pray it every day, then every week, if not every week, then at least once a month. If you cannot do so, then at least once a year, if you cannot do so, then once in your lifetime, pray this salāh.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-greatest-form-of-repentance-tasbh-salh/">619 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_20.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/that-which-is-more-precious-than-wealth-and-royalty/" rel="bookmark" class="entry-date">
                                          20 Jan 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/that-which-is-more-precious-than-wealth-and-royalty/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/that-which-is-more-precious-than-wealth-and-royalty/">THAT WHICH IS MORE PRECIOUS THAN WEALTH AND ROYALTY</a>
                              </h4>
                              <p class="mt-3">Another blessing Sulaymān (‘alayhis salām) was bestowed by Allāh Ta‘ālā was that the wind would convey speeches of people to Sulaymān (‘alayhis salām).
One day, a farmer saw Sulaymān (‘alayhis salām) travelling in the sky with his troops and watched them in astonishment, saying: “What a great wealth and royalty Allāh Ta‘ālā blessed the family of Dāwūd!” On hearing these words, Sulaymān (alayhis salām) landed near the farmer and advised him: “I landed here to give you this advice: Do not yearn to possess what you cannot handle. By Allāh, one accepted tasbīh (saying Subḥānallāh) is superior to all the worldly blessings given to the family of Dāwūd.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/that-which-is-more-precious-than-wealth-and-royalty/">630 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_19.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/a-person-well-known-among-the-angels/" rel="bookmark" class="entry-date">
                                          12 Jan 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/a-person-well-known-among-the-angels/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/a-person-well-known-among-the-angels/">A PERSON WELL-KNOWN AMONG THE ANGELS</a>
                              </h4>
                              <p class="mt-3">One day Jibrā’īl (‘alayhis salām) was sitting with Rasūlullāh (sallallāhu ‘alayhi wa sallam). Meanwhile, Abu Dharr al-Ghifārī (raḍiyallāhu ‘anhu) appeared from far. Jibrā’īl (‘alayhis salām) said: “This coming person is Abū Dharr.” Rasūlullāh (sallallāhu ‘alayhi wa sallam) asked: “Do you know him?” Jibrā’īl (‘alayhis salām) said: “He is much more well known among angels than he is known among people.” Rasūlullāh (sallallāhu ‘alayhi wa sallam) asked: “How did he attain this degree?” Jibrā’īl (alayhis salām) replied: “This is because he struggles against his nafs (lower-self) constantly and recites Sūrah al-Ikhlās a lot.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/a-person-well-known-among-the-angels/">709 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_18.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/fruits-banana/" rel="bookmark" class="entry-date">
                                          05 Jan 2023
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/fruits-banana/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/fruits-banana/">FRUITS: BANANA</a>
                              </h4>
                              <p class="mt-3">Allāh Ta‘ālā mentions the blessings the people of Jannah (Paradise) will have in the 28th and 29th āyahs of Sūrah al-Wāqi‘ah: “They (Ashāb-e yamīn whose books will be given from the right) will be among thornless cherry- trees, and banana trees layered [with fruit].”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/fruits-banana/">1,037 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_17.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/resemble/" rel="bookmark" class="entry-date">
                                          28 Dec 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/resemble/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/resemble/">Resemble</a>
                              </h4>
                              <p class="mt-3">A person who follows Rasulullah (sallallahu alayhi wa sallam) should abstain from what he (sallallahu alayhi wa sallam) abstained from.
A person who follows the ways of people whom Rasulullah (sallallahu alayhi wa sallam) stayed away from will have opposed Rasulullah (sallallahu alayhi wa sallam)

Hulbu’t-Ta’i (radiyallahu anhu) reported that Rasulullah (sallallahu alayhi wa sallam) said: “Let no desire awaken in your heart that will make you resemble the Christians.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/resemble/">705 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_16.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/tashabbuh-2/" rel="bookmark" class="entry-date">
                                          22 Dec 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/tashabbuh-2/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/tashabbuh-2/">TASHABBUH</a>
                              </h4>
                              <p class="mt-3">TASHABBUH (TRYING TO RESEMBLE OTHERS)

Tashabbuh is the resemblance of a person to another in physical appearance, clothing, lifestyle, character, attributes, and qualities or trying to resemble them by imitating their ways.
Muslims are obliged to refrain from imitating the customs and traditions of the Kuffar (infidels). Because it either leads one to Kufr (disbelief) or weakens their Iman (faith).
Allah Ta‘ala says: “And whoever opposes the Prophet after the right path has been shown clearly to him, and follows other than the believers’ way (in faith, acts and obedience to Allah, His Rasul and Ulul-Amr). We shall keep him in the path he has chosen and drive him to the Hell - what an evil destination.” (Surah al-Nisa, Ayah 115)  </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/tashabbuh-2/">798 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_15.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/five-nights/" rel="bookmark" class="entry-date">
                                          16 Dec 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/five-nights/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/five-nights/">Five Nights</a>
                              </h4>
                              <p class="mt-3">Rasûlullah (sallallâhu alayhi wa sallam) said: “There are five nights in which Du‘âs (supplications) are not rejected: Jumu‘ah (Friday) night, first night of Rajab, the night of half of Sha‘bân (Laylah al-Barâ’ah), night of Eid al-Fitr, and night of Eid al-Adhâ.” (Bayhaqî, Shu‘ab al-Îmân)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/five-nights/">643 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_14.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/pray-nafilah-at-night/" rel="bookmark" class="entry-date">
                                          05 Dec 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/pray-nafilah-at-night/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/pray-nafilah-at-night/">Pray (Nâfilah) at Night</a>
                              </h4>
                              <p class="mt-3">Rasûlullah (sallallâhu alayhi wa sallam) said: “If
a person goes to his bed intending to get up
and pray (Nâfilah) at night, then sleep
overwhelms him until morning (time of Fajr),
(the reward of) what he intended will be
recorded for him as rewards and his sleep is a
charity given to him</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/pray-nafilah-at-night/">700 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_13.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/noble-quran-/" rel="bookmark" class="entry-date">
                                          02 Dec 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/noble-quran-/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/noble-quran-/">Noble Qur’ân </a>
                              </h4>
                              <p class="mt-3">Rasûlullah (sallallâhu alayhi wa sallam) said: “There is no poverty concerning any servant reciting the Noble Qur’ân and there are no greater riches (needed) for that servant.” (Al-Musannaf ibn Abî Shaybah)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/noble-quran-/">643 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_12.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/winter-ibadah/" rel="bookmark" class="entry-date">
                                          22 Nov 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/winter-ibadah/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/winter-ibadah/">Winter Ibadah</a>
                              </h4>
                              <p class="mt-3">Rasulullah (sallallahu alayhi wa sallam) said: “Winter is the spring of a believer. The days are short so they fast and the nights are long so they pray (Tahajjud and make Dhikr).” (Bayhaqi, Shu‘ab al-Iman)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/winter-ibadah/">730 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_11.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/knowledge-2/" rel="bookmark" class="entry-date">
                                          17 Nov 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/knowledge-2/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/knowledge-2/">Knowledge</a>
                              </h4>
                              <p class="mt-3">Rasulullah (sallallahu alayhi wa sallam) said: “Acquire knowledge. And acquire peace, tranquillity, and dignity for knowledge. Humble yourself before the person from whom you acquire knowledge.” (Tabarani, al-Mu‘jam al- Awsat)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/knowledge-2/">793 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_10.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/keep-my-heart-firm-on-your-religion/" rel="bookmark" class="entry-date">
                                          09 Nov 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/keep-my-heart-firm-on-your-religion/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/keep-my-heart-firm-on-your-religion/">Keep my heart  firm on your religion</a>
                              </h4>
                              <p class="mt-3">Mother of the believers, Hadrat Umm Salamah (radiyallahu anha) said: “(Among) The Du‘as which Rasulullah (sallallahu alayhi wa sallam) often made was, ‘Ya muqalliba’l-qulub, thabbit qalbi ‘ala dinika’ (O, Allah who changes the hearts! Keep my heart firm on your religion).” (Sunan al-Tirmidhi)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/keep-my-heart-firm-on-your-religion/">859 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_6.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/true-believers/" rel="bookmark" class="entry-date">
                                          04 Nov 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/true-believers/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/true-believers/">True Believers</a>
                              </h4>
                              <p class="mt-3">Rasulullah (sallallahu alayhi wa sallam) said: “Adhere to righteousness even though you will not be able to count it (the reward you will achieve from righteousness). Know that the best of your acts is Salah. Indeed, the (true) believers will always be in a state of Wudu.” (Sunan Ibn Majah)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/true-believers/">748 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_9.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/eat-of-the-good-lawful/" rel="bookmark" class="entry-date">
                                          27 Oct 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/eat-of-the-good-lawful/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/eat-of-the-good-lawful/">Eat of the good (lawful)</a>
                              </h4>
                              <p class="mt-3">Allah Ta‘ala says:“O, you who believe! Eat of the good (lawful) things that we provided you and be grateful to Allah, if it is (indeed) Him that you worship.”(Surahal-Baqarah, Ayah172)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/eat-of-the-good-lawful/">1,053 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_7.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/good-friend/" rel="bookmark" class="entry-date">
                                          20 Oct 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/good-friend/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/good-friend/">Good Friend</a>
                              </h4>
                              <p class="mt-3">Rasulullah (sallallahu alayhi wa sallam) said: “The similitude of a good friend is like a person who sells perfumes. Even if you do not buy anything (perfume) from him, you benefit from the fragrant smell of his shop. As for the similitude of a bad friend, it is like the blacksmith. Even if his fire (in the furnace) does not burn your clothes, its smoke and fumes will get to you.”
Sufyan bin Uyaynah (rahmatullahi alayh) said:* “A person who loves a Salih (righteous) person will have indeed loved Allah Azza wa Jalla.”*
</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/good-friend/">759 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_6.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/mawlid-an-nabawi/" rel="bookmark" class="entry-date">
                                          06 Oct 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/mawlid-an-nabawi/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/mawlid-an-nabawi/">MAWLID AN-NABAWI</a>
                              </h4>
                              <p class="mt-3">Rasulullah (sallallahu alayhi wa sallam) blessed the universe with his birth on the 12th of this month. Therefore, the twelfth of Rabi‘ al-Awwal is the night of  Waladat (Mawlid), a sacred night in the Hijri Calendar.

During this month, Muslims should engage in reciting Salawat (Durud) Sharif, such as Salat al-Nariyyah, Salat al-Munjiyah and Salat al-Fathiya as many times as possible.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/mawlid-an-nabawi/">1,022 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_5.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/taqwa/" rel="bookmark" class="entry-date">
                                          21 Sep 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/taqwa/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/taqwa/">TAQWÂ</a>
                              </h4>
                              <p class="mt-3">Taqwâ is to fear Allâh Ta‘âlâ, abstain from sins and the things that may lead to humiliation, and to restrain the Nafs (lower self) from unlawful acts. A person with Taqwâ trying to fulfil his religious duties is called Muttaqî.

A person asked Hadrat Abû Hurayrah (radiyallâhu anhu): “What is Taqwâ?” He said: “Have you ever walked on a thorny path?” The man said: “Yes, I have.” Abû Hurayrah (radiyallâhu anhu) asked: “How did you walk there?” The man replied: “By abstaining from being pricked by them.”

Abû Hurayrah (radiyallâhu anhu) said: “Then, abstain from sins just like you did from the thorns, that is Taqwâ.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/taqwa/">905 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_4.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/good-character-is-a-sign-of-iman/" rel="bookmark" class="entry-date">
                                          08 Sep 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/good-character-is-a-sign-of-iman/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/good-character-is-a-sign-of-iman/">GOOD CHARACTER IS A SIGN OF ÎMÂN</a>
                              </h4>
                              <p class="mt-3">Good character is the sign of Îmân and adornment of Islam. Muslims should rid themselves of evil habits and adorn themselves with good manners. Bad character misleads a person to sin, whereas good character leads to salvation and prosperity in Dunyâ and the Âkhirah.

People who follow the straight path drawn by our religion cannot act immorally because our religion prohibits every one of the misdeeds and offences that violate peace and prosperity. There are even certain penalties to be executed in this world and in the Hereafter about those who violate these religious prohibitions.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/good-character-is-a-sign-of-iman/">1,621 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_3.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/islamic-brotherhood/" rel="bookmark" class="entry-date">
                                          26 Aug 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/islamic-brotherhood/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/islamic-brotherhood/">ISLAMIC BROTHERHOOD</a>
                              </h4>
                              <p class="mt-3">The love among the fellow brothers in religion (Islam) increases with their sincerity, honesty, and loyalty. Sincerity among them leads to Wafâ, which is the constancy in friendship and the highest level of love and sincerity. The Prophet of Allâh (sallallâhu alayhi wa sallam) established brotherhood among his Sahâbah (companions) through which sincerity and love increased and their support to each other strengthened. In this regard, Nabî (sallallâhu alayhi wa sallam) said: “I advise you to take sincere and pure fellow brothers, for they are (like) ornament to you at times of ease, and security at times of calamities.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/islamic-brotherhood/">1,297 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate_2.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/who-is-blessed-with-real-salvation-/" rel="bookmark" class="entry-date">
                                          18 Aug 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/who-is-blessed-with-real-salvation-/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/who-is-blessed-with-real-salvation-/">WHO IS BLESSED WITH REAL SALVATION ?</a>
                              </h4>
                              <p class="mt-3">People praised a person in the company of Ahmad bin Hanbal (rahmatullâhi alayh). Hearing their praises, Ahmad bin Hanbal (rahmatullâhi alayh) commented: “Beloved sons, the person who attains the real salvation is the one who attains salvation on the Day of Resurrection, and is not confronted by anyone claiming for their rights.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/who-is-blessed-with-real-salvation-/">1,498 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/teamplate.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/who-repents-from-his-sins/" rel="bookmark" class="entry-date">
                                          11 Aug 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/who-repents-from-his-sins/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/who-repents-from-his-sins/">There is nobody more beloved to  who repents from his sins</a>
                              </h4>
                              <p class="mt-3">Nabî (sallallâhu alayhi wa sallam) said:

“There is nobody more beloved to Allâh Ta‘âlâ than a youth who repents from his sins.

And there is nobody more disliked by Allâh Ta‘âlâ than an old man persisting in sins.” (Kanz al-‘Ummâl)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/who-repents-from-his-sins/">843 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/ashura-day_2.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/what-to-do-on-the-day-of-ashura/" rel="bookmark" class="entry-date">
                                          03 Aug 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/what-to-do-on-the-day-of-ashura/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/what-to-do-on-the-day-of-ashura/">WHAT TO DO ON THE DAY OF ÂSHÛRÂ</a>
                              </h4>
                              <p class="mt-3">If groceries are bought on this day, there will be Barakâh in one’s home for the rest of the year.

Salâm should be given to at least 10 Muslims or a Muslim should be given Salâm 10 times.

The poor should be made happy.

Those who take a Ghusl bath on that day, shall not experience ailments for the rest of the year.

</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/what-to-do-on-the-day-of-ashura/">1,107 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/ddddddadsa.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-most-virtuous-day-the-day-of-arafah/" rel="bookmark" class="entry-date">
                                          07 Jul 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-most-virtuous-day-the-day-of-arafah/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-most-virtuous-day-the-day-of-arafah/">THE MOST VIRTUOUS DAY: THE DAY OF ARAFAH</a>
                              </h4>
                              <p class="mt-3">Rasûlullâh (sallallâhu alayhi wa sallam) said: “There is not a day that is more virtuous than the day of Arafah in the sight of Allâh Azza wa Jalla. On the day of Arafah, Allâh Ta‘âlâ manifests in the heaven with His mercy, praising His servants on Earth to His angels in heaven by saying: “Look at my servants.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-most-virtuous-day-the-day-of-arafah/">1,090 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_5.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/watermelon-a-fruit-of-jannah/" rel="bookmark" class="entry-date">
                                          09 Jun 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/watermelon-a-fruit-of-jannah/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/watermelon-a-fruit-of-jannah/">WATERMELON: A FRUIT OF JANNAH</a>
                              </h4>
                              <p class="mt-3">Watermelon grows in hot and warm climates. It is planted in spring after the risk of frost and white frost disappear. Particularly river and lakesides are suitable for growing watermelons.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/watermelon-a-fruit-of-jannah/">3,411 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_4.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/hajj-an-ibadah-with-wealth-and-body/" rel="bookmark" class="entry-date">
                                          27 May 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/hajj-an-ibadah-with-wealth-and-body/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/hajj-an-ibadah-with-wealth-and-body/">HAJJ, AN IBÂDAH WITH WEALTH AND BODY</a>
                              </h4>
                              <p class="mt-3">Hajj (pilgrimage) is one of the five pillars of Islam. It is an Ibâdah (worship) carried out with wealth and body.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/hajj-an-ibadah-with-wealth-and-body/">1,212 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Site_2.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/joy-of-ramadan/" rel="bookmark" class="entry-date">
                                          24 Mar 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/joy-of-ramadan/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/joy-of-ramadan/">JOY OF RAMADÂN</a>
                              </h4>
                              <p class="mt-3">Ramadân al-Sharîf is the month in which the excellent qualities of Islam become more apparent and are practiced by the believers. Collective Ibâdahs (acts of worship) performed in various places are offered in this month with a sincere heart.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/joy-of-ramadan/">1,684 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Blue_Mosque_11X17_Turkish_Food_Festival_2022_Placemats_09_2.20">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/festivalmenu/" rel="bookmark" class="entry-date">
                                          18 Mar 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/festivalmenu/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/festivalmenu/">Festival Menu</a>
                              </h4>
                              <p class="mt-3">Rizq is the necessities of life that Allâh Ta‘âlâ provides to the living creatures to sustain their lives.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/festivalmenu/">1,502 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_3.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/earning-halal/" rel="bookmark" class="entry-date">
                                          18 Mar 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/earning-halal/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/earning-halal/">EARNING HALAL</a>
                              </h4>
                              <p class="mt-3">Rizq is the necessities of life that Allâh Ta‘âlâ provides to the living creatures to sustain their lives.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/earning-halal/">3,082 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2022-02-27--Ibadah_on_Lailatu_Al_Miraj.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/ibadah-on-the-night-of-miraj-and-the-following-day/" rel="bookmark" class="entry-date">
                                          27 Feb 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/ibadah-on-the-night-of-miraj-and-the-following-day/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/ibadah-on-the-night-of-miraj-and-the-following-day/">Ibadah On The Night Of Mi;raj And The Following Day</a>
                              </h4>
                              <p class="mt-3">The 27th night of Rajab al-Sharîf is the Night of M‘irâj. A Hâjah Salâh (Salâh of Needs) consisting of twelve Rak‘ahs should be performed after Ishâ Salâh. In each Rak‘ah, after Sûrah al-Fâtihah, Surah al-Ikhlâs is recited 10 times.....</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/ibadah-on-the-night-of-miraj-and-the-following-day/">1,646 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2022-02-27--Lailatu_Al_Miraj.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-miracle-of-miraj/" rel="bookmark" class="entry-date">
                                          27 Feb 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-miracle-of-miraj/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-miracle-of-miraj/">The Miracle Of Mi;raj</a>
                              </h4>
                              <p class="mt-3">The miracle of Mi‘râj took place a year before the Hijrah, on the 27th night of Rajab al-Sharîf. This incident was mentioned in the first Âyah of Sûrah al-Isrâ. If a person denies that Rasûlullâh (saw) travelled from ...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-miracle-of-miraj/">1,650 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_2.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/what-is-the-dua-to-read-when-entering-and-leaving-the-toilet/" rel="bookmark" class="entry-date">
                                          03 Feb 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/what-is-the-dua-to-read-when-entering-and-leaving-the-toilet/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/what-is-the-dua-to-read-when-entering-and-leaving-the-toilet/">What is the dua to read when entering and leaving the toilet?</a>
                              </h4>
                              <p class="mt-3">Observing Âdâb (good manners) on every occasion is essential, and so is the case regarding the use of toilet.
Before entering the toilet, one should remove their socks and roll up their trouser legs.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/what-is-the-dua-to-read-when-entering-and-leaving-the-toilet/">1,402 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/what-is-the-virtue-of-jumuah-friday-/" rel="bookmark" class="entry-date">
                                          27 Jan 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/what-is-the-virtue-of-jumuah-friday-/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/what-is-the-virtue-of-jumuah-friday-/">What is the Virtue of Jumuah (Friday) ?</a>
                              </h4>
                              <p class="mt-3">The day of Jumu‘ah (Friday) is held sacred by Muslims. It came in a Hadith Al-Sharif as follows: “The best day on which the sun has risen is Friday. Adam (Alayhis Salam) was created on Friday, on it he entered Jannah (Paradise), and on it he was taken out from therein. The Hour will not be established but on Friday.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/what-is-the-virtue-of-jumuah-friday-/">2,323 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web-Site_2.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/what-is-wudu-what-are-the-fardh-obligatory-acts-of-wudu/" rel="bookmark" class="entry-date">
                                          20 Jan 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/what-is-wudu-what-are-the-fardh-obligatory-acts-of-wudu/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/what-is-wudu-what-are-the-fardh-obligatory-acts-of-wudu/">What is Wudu? What are the Fardh (obligatory) acts of Wudu?</a>
                              </h4>
                              <p class="mt-3">Wudû is a form of religious purity, which includes washing and wiping certain parts of one’s body in accordance with religious rules.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/what-is-wudu-what-are-the-fardh-obligatory-acts-of-wudu/">43,931 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Sitesi_Background.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/what-is-the-virtue-of-basmalah-shareef/" rel="bookmark" class="entry-date">
                                          06 Jan 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/what-is-the-virtue-of-basmalah-shareef/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/what-is-the-virtue-of-basmalah-shareef/">What is the Virtue of Basmalah Shareef ?</a>
                              </h4>
                              <p class="mt-3">It is Mustahab (recommended) to recite Basmalah (Bismillâhirrahmânirrahim) at the beginning of any good deed.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/what-is-the-virtue-of-basmalah-shareef/">1,579 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Site.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/can-the-quran-al-kareem-be-held-without-wudu/" rel="bookmark" class="entry-date">
                                          06 Jan 2022
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/can-the-quran-al-kareem-be-held-without-wudu/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/can-the-quran-al-kareem-be-held-without-wudu/">Can The Qur;an Al Kareem  Be Held Without Wudu?</a>
                              </h4>
                              <p class="mt-3">The ruling is the same for the parts of the Qur’ân where the text of verses is printed and where it is not. Therefore, a person without Wudû can neither touch its parts where its text is printed nor at the margins. It is Fard (obligatory) to perform Wudû to touch or hold the Qur’ân be it an Âyah (verse) written on a piece of paper or hanging on a wall.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/can-the-quran-al-kareem-be-held-without-wudu/">1,629 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/tashabbuh/" rel="bookmark" class="entry-date">
                                          30 Dec 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/tashabbuh/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/tashabbuh/">TASHABBUH (TRYING TO RESEMBLANCE OTHERS)</a>
                              </h4>
                              <p class="mt-3">Muslims are obliged to refrain from imitating the customs and traditions of Kuffar (infidels). Because it either leads one to Kufr (disbelief) or weakens their iman (faith).</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/tashabbuh/">2,364 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/WEB-Sitesi.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/a-person-is-together-with-whom-he-loves/" rel="bookmark" class="entry-date">
                                          23 Dec 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/a-person-is-together-with-whom-he-loves/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/a-person-is-together-with-whom-he-loves/">A Person Is Together With Whom He Loves</a>
                              </h4>
                              <p class="mt-3">Rasûlullâh Sallallâhu Alayhi Wa Sallam said: “A person is together with whom he loves.” When a person’s heart inclines to someone, so does his mind and thoughts. Then, he tries to imitate the attitudes, state, and behaviours of the person he loves. Thus, they are both in a similar situation.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/a-person-is-together-with-whom-he-loves/">1,529 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web-Site.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/virtues-of-friday/" rel="bookmark" class="entry-date">
                                          16 Dec 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/virtues-of-friday/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/virtues-of-friday/">VIRTUES OF FRIDAY</a>
                              </h4>
                              <p class="mt-3">he day of Jumu‘ah (Friday) is held sacred by Muslims. It came in a Hadith Al-Sharif as follows: “The best day on which the sun has risen is Friday. Adam (Alayhis Salam) was created on Friday, on it he entered Jannah (Paradise), and on it he was taken out from therein. The Hour will not be established but on Friday.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/virtues-of-friday/">1,416 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Jumuah-Mubarak.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abstaining-from-the-doubtful/" rel="bookmark" class="entry-date">
                                          09 Dec 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abstaining-from-the-doubtful/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abstaining-from-the-doubtful/">ABSTAINING FROM THE DOUBTFUL</a>
                              </h4>
                              <p class="mt-3">Rasûlullâh Sallallâhu Alayhi Wa Sallam said: Halal (lawful) is clear, and Haram (prohibited) is clear. In between them are certain doubtful things, concerning which most people do not know if they are Halal or Haram.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abstaining-from-the-doubtful/">2,930 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_copy_2.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/some-nafilah-salah/" rel="bookmark" class="entry-date">
                                          25 Nov 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/some-nafilah-salah/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/some-nafilah-salah/">SOME NAFILAH (OPTIONAL) SALAH</a>
                              </h4>
                              <p class="mt-3">Besides Fardh Salah (compulsory prayers), Muslims should also make an effort to perform the nafilah Salah such as Dhuha, Awwabin, Tahajjud and Tasbih. Because, these nafilah Salah have numerous thawab (rewards) for the believers.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/some-nafilah-salah/">2,066 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Sitesi_5.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/aqiqah-qurbani/" rel="bookmark" class="entry-date">
                                          18 Nov 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/aqiqah-qurbani/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/aqiqah-qurbani/">AQIQAH IS A MUSTAHAB (RECOMMENDED) SACRIFICE</a>
                              </h4>
                              <p class="mt-3">The hair on the head of a newborn baby is called aqiqah. And the animal that is sacrificed after a baby is born to thank Allah Ta’ala is also called aqiqah. According to the Hanafi mazhab, aqiqah sacrifice is mustahab (recommended) and Sunnah according to the other 3 mazhabs.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/aqiqah-qurbani/">2,353 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-08-26_copy.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/to-give-salaam-2/" rel="bookmark" class="entry-date">
                                          11 Nov 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/to-give-salaam-2/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/to-give-salaam-2/">TO GIVE SALAAM</a>
                              </h4>
                              <p class="mt-3">Rasûlullâh Sallallâhu Alayhi Wa Sallam said, 
“Indeed As-Salaam is one of the Beautiful Names of Allah. He sent the Salaam down to the Earth as a greeting.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/to-give-salaam-2/">1,542 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Sitesi_4.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/dua-of-athan/" rel="bookmark" class="entry-date">
                                          22 Oct 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/dua-of-athan/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/dua-of-athan/">Those Who Recite The Dua Of Athan Will Be Entitled To Shafa’ah</a>
                              </h4>
                              <p class="mt-3">Rasûlullâh Sallallâhu Alayhi Wa Sallam said:

“When you hear the muazzin, repeat what he recites and send Salawat (blessings) upon me...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/dua-of-athan/">2,052 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Sitesi_3.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/from-the-last-sermon-of-raslullah-saw/" rel="bookmark" class="entry-date">
                                          13 Oct 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/from-the-last-sermon-of-raslullah-saw/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/from-the-last-sermon-of-raslullah-saw/">From The Last Sermon Of Rasûlullâh (SAW)</a>
                              </h4>
                              <p class="mt-3">‘’O people! Lend me an attentive ear. I do not know, whether after this year, I shall be amongs you.
O people, just as you regard this month, this day and this city sacred, so regard the life and property of every Muslim as a sacred trust.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/from-the-last-sermon-of-raslullah-saw/">1,280 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Sitesi_2.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-month-of-rabi-al-awwal/" rel="bookmark" class="entry-date">
                                          07 Oct 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-month-of-rabi-al-awwal/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-month-of-rabi-al-awwal/">The Month Of Rabiʽ Al-Awwal</a>
                              </h4>
                              <p class="mt-3">Muslims should engage in reciting Salawât (Durood) Sharîf, such as Salat-Nariyyah, Salat-Munjiyah and Salat Al-Fathiya as many times as possible.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-month-of-rabi-al-awwal/">1,433 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Site.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/virtue-of-reciting-the-noble-quran/" rel="bookmark" class="entry-date">
                                          30 Sep 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/virtue-of-reciting-the-noble-quran/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/virtue-of-reciting-the-noble-quran/">Virtue Of Reciting The Noble Qur;an</a>
                              </h4>
                              <p class="mt-3">“Whoever listens to one Ayah from the book of Allah Subhanahu (Al-Qur’an Al-Karim), rewards are written for him in multiple folds. And whoever reads one Ayah, it will be a nur (light) for him on the Day of Qiyamah (Judgment).”
</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/virtue-of-reciting-the-noble-quran/">1,985 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_2.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/on-aadab-etiquettes-of-sleeping/" rel="bookmark" class="entry-date">
                                          23 Sep 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/on-aadab-etiquettes-of-sleeping/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/on-aadab-etiquettes-of-sleeping/">On Aadab (Etiquettes) Of Sleeping</a>
                              </h4>
                              <p class="mt-3">AIshâ Radhiyallâhu Anha reported that when Rasûlullâh Sallallâhu Alayhi Wa Sallam lied down to sleep, he lied on his right side while his blessed face facing the Qiblah.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/on-aadab-etiquettes-of-sleeping/">2,069 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_sitesi.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/when-the-servant-of-allah-says-alhamdulillah/" rel="bookmark" class="entry-date">
                                          09 Sep 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/when-the-servant-of-allah-says-alhamdulillah/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/when-the-servant-of-allah-says-alhamdulillah/">When The Servant Of Allah Says "Alhamdulillah"</a>
                              </h4>
                              <p class="mt-3">When Allâh Ta‘âlâ bestows a Nimah (favour), little or large, upon His servant and the servant responds them saying “Alhamdulillah” (Thanks be to Allah) in return, verily this hamd (Gratitude, praise) of the servant is better than that Nimah itself</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/when-the-servant-of-allah-says-alhamdulillah/">3,098 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/web.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/learning-and-reciting-the-noble-quran/" rel="bookmark" class="entry-date">
                                          02 Sep 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/learning-and-reciting-the-noble-quran/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/learning-and-reciting-the-noble-quran/">Learning And Reciting The Noble Qur;an</a>
                              </h4>
                              <p class="mt-3">It is Fardh Al-Ayn (compulsory for each Muslim individually) to memorize enough Surahs and Ayat (verses) from the Holy Qur’an to make one’s Salah acceptable. It is Wâjib (required) to memorize Surah Al-Fatiha and another Surah so that Fardh is fulfilled.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/learning-and-reciting-the-noble-quran/">1,981 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/web_sitesi.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-value-of-good-manners/" rel="bookmark" class="entry-date">
                                          26 Aug 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-value-of-good-manners/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-value-of-good-manners/">The Value Of Good Manners</a>
                              </h4>
                              <p class="mt-3">Akhlaq means disposition and character. Part of the Akhlaq is called ‘Akhlaq-e Hamidah’ (praised manners) as they are highly appreciated, such as humbleness, courage, generosity, and truthfulness. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-value-of-good-manners/">7,518 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Web_Sitesi_1.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/salah-advised-on-the-9th-and-10th-nights-of-muharram/" rel="bookmark" class="entry-date">
                                          12 Aug 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/salah-advised-on-the-9th-and-10th-nights-of-muharram/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/salah-advised-on-the-9th-and-10th-nights-of-muharram/">Salâh Advised On The 9th And 10th Nights Of Muharram</a>
                              </h4>
                              <p class="mt-3">Muslims should strictly avoid speeches, quarrels, or writings that could hurt people’s feelings and cause hatred or friction between people. Wise and kind words and beneficial writings touch the souls, attract the hearts and help one to achieve their intended target.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/salah-advised-on-the-9th-and-10th-nights-of-muharram/">1,436 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Jumuah_Mubarak.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-month-of-muharram/" rel="bookmark" class="entry-date">
                                          05 Aug 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-month-of-muharram/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-month-of-muharram/">The Month Of Muharram</a>
                              </h4>
                              <p class="mt-3">Muslims should strictly avoid speeches, quarrels, or writings that could hurt people’s feelings and cause hatred or friction between people. Wise and kind words and beneficial writings touch the souls, attract the hearts and help one to achieve their intended target.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-month-of-muharram/">2,048 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/web_site.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/physical-distance-is-not-an-obstacle-to-acquire-knowledge/" rel="bookmark" class="entry-date">
                                          05 Aug 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/physical-distance-is-not-an-obstacle-to-acquire-knowledge/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/physical-distance-is-not-an-obstacle-to-acquire-knowledge/">Physical Distance Is Not An Obstacle To Acquire Knowledge</a>
                              </h4>
                              <p class="mt-3">Muslims should strictly avoid speeches, quarrels, or writings that could hurt people’s feelings and cause hatred or friction between people. Wise and kind words and beneficial writings touch the souls, attract the hearts and help one to achieve their intended target.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/physical-distance-is-not-an-obstacle-to-acquire-knowledge/">1,339 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/An_Important_Task_Of_Muslims--640x640.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/an-important-task-of-muslims-to-speak-kindly/" rel="bookmark" class="entry-date">
                                          29 Jul 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/an-important-task-of-muslims-to-speak-kindly/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/an-important-task-of-muslims-to-speak-kindly/">An Important Task Of Muslims: To Speak Kindly</a>
                              </h4>
                              <p class="mt-3">Muslims should strictly avoid speeches, quarrels, or writings that could hurt people’s feelings and cause hatred or friction between people. Wise and kind words and beneficial writings touch the souls, attract the hearts and help one to achieve their intended target.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/an-important-task-of-muslims-to-speak-kindly/">2,849 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Ukhuwwah_-_Brotherhood--600x600.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/ukhuwwah-brotherhood/" rel="bookmark" class="entry-date">
                                          23 Jul 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/ukhuwwah-brotherhood/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/ukhuwwah-brotherhood/">Ukhuwwah (Brotherhood)</a>
                              </h4>
                              <p class="mt-3">Ukhuwwah means love, friendship, bond, and brotherhood. It is the brotherhood established for the sake of Allah without expecting anything in return. The bond of brotherhood among fellow Muslims is far more precious than the brotherhood in a family. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/ukhuwwah-brotherhood/">1,964 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/About_The_Tashriq_Takbeer.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/about-tashriq-takbeer/" rel="bookmark" class="entry-date">
                                          18 Jul 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/about-tashriq-takbeer/" rel="bookmark" class="entry-category">
                                          Qurbani
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/about-tashriq-takbeer/">About Tashriq Takbeer</a>
                              </h4>
                              <p class="mt-3">Tashriq Takbir is the Takbir recited on the Days of Tashriq. It is Wajib for every liable Muslim. Surah Al-Baqarah Ayah 203, which says: “Celebrate the praises of Allah during the Appointed Days.”, indicates the Tashriq Takbeer.

</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/about-tashriq-takbeer/">4,277 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Mustahaabs_Of_Qurbani--600x600.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/mustahaabs-of-qurbani/" rel="bookmark" class="entry-date">
                                          16 Jul 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/mustahaabs-of-qurbani/" rel="bookmark" class="entry-category">
                                          Qurbani
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/mustahaabs-of-qurbani/">Mustahaabs Of Qurbani</a>
                              </h4>
                              <p class="mt-3">Rasulullah (Sallalahu Alayhi Wa Sallam) said: “The son of Adam does not perform any action on the day of Nahr (Eid Al-Adha) which is more beloved to Allah than causing the blood (of the Udhiyyah) to flow”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/mustahaabs-of-qurbani/">2,712 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Qurbani-150--6060x600.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/some-rules-concerning-qurbani/" rel="bookmark" class="entry-date">
                                          09 Jul 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/some-rules-concerning-qurbani/" rel="bookmark" class="entry-category">
                                          Qurbani
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/some-rules-concerning-qurbani/">Some Rules Concerning Qurbani</a>
                              </h4>
                              <p class="mt-3">If a person does not fulfil their Qurbani obligation in time, then giving its value as donation in money will not be a substitute. If rich people do not fulfil their Qurbani obligation and the time of sacrifice passes, then they will need to give the value of the Qurbani in money as donation.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/some-rules-concerning-qurbani/">1,699 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Merits_Of_Udhiyyah--600x600.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/merits-of-udhiyyah-qurbani/" rel="bookmark" class="entry-date">
                                          02 Jul 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/merits-of-udhiyyah-qurbani/" rel="bookmark" class="entry-category">
                                          Qurbani
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/merits-of-udhiyyah-qurbani/">Merits Of Udhiyyah (Qurbani)</a>
                              </h4>
                              <p class="mt-3">Our Prophet (Sallallâhu Alayhi Wa Sallam) said:  “The Day of Nahr (10th of Dhul-Hijjah) is one of the greatest days with Allah.” Whoever approaches his sacrificial animal on the day of Nahr to slaughter it, Allah’s mercy will also approach (bless) him in Jannah.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/merits-of-udhiyyah-qurbani/">1,773 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Some_Benefits_Of_Qurbani.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/some-benefits-of-qurbani/" rel="bookmark" class="entry-date">
                                          25 Jun 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/some-benefits-of-qurbani/" rel="bookmark" class="entry-category">
                                          Qurbani
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/some-benefits-of-qurbani/">Some Benefits Of Qurbani</a>
                              </h4>
                              <p class="mt-3">With Qurbani there is a feast for servants of Allah (s.w.t). There is a devotion in the cause of Allah (s.w.t) in performing Qurbani. It is a way of showing gratitude to the many blessings Allah (s.w.t) has given us, to get closer to Allah, gain rewards and it also acts as a barrier against troubles.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/some-benefits-of-qurbani/">5,838 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Children_Who_Open_The_Gates_Of_Jannah--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/children-who-open-the-gates-of-jannah/" rel="bookmark" class="entry-date">
                                          18 Jun 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/children-who-open-the-gates-of-jannah/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/children-who-open-the-gates-of-jannah/">Children Who Open The Gates Of Jannah</a>
                              </h4>
                              <p class="mt-3">Whenever Rasulullah (S.A.W.) sat on a place to preach a group of his sahaba (R.A.), children would also sit around him. One of the sahaba had a son. This boy used to follow his father who used to make him sit on his lap while listening to the Prophet of Allah (S.A.W.).</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/children-who-open-the-gates-of-jannah/">1,693 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Characteristics_Of_A_Kamil_Mumin.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/characteristics-of-a-kamil-perfect-mumin/" rel="bookmark" class="entry-date">
                                          11 Jun 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/characteristics-of-a-kamil-perfect-mumin/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/characteristics-of-a-kamil-perfect-mumin/">Characteristics Of A Kamil (Perfect) Mu;min</a>
                              </h4>
                              <p class="mt-3">Our Noble Prophet (Sallalahu Alayhi Wa Sallam) said: “Indeed these qualities are among the characteristics of a kamil mu’min:
He is firm in his religion. He carries out his affairs easily and gently but properly. He has yaqin (firm belief) in his iman.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/characteristics-of-a-kamil-perfect-mumin/">4,921 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Qurbani--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/qurbani-2021/" rel="bookmark" class="entry-date">
                                          04 Jun 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/qurbani-2021/" rel="bookmark" class="entry-category">
                                          Qurbani
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/qurbani-2021/">Qurbani</a>
                              </h4>
                              <p class="mt-3">Five animals (sheep, goat, cattle, water buffalo, camel) that are sacrificed to gain the blessing of and to become closer to Allah (s.w.t) on the days of Eid-ul Adha are called Qurbani. According to Hanafi Fiqh it is Wajib upon every Muslim who has the wealth equal to the Nisaab to sacrifice a Qurbani once a year on Eid-ul Adha.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/qurbani-2021/">1,947 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Merits_Of_Learning_The_Quran_Al_Kareem.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/merits-of-learning-the-quran-al-kareem/" rel="bookmark" class="entry-date">
                                          28 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/merits-of-learning-the-quran-al-kareem/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/merits-of-learning-the-quran-al-kareem/">Merits Of Learning The Quran Al Kareem</a>
                              </h4>
                              <p class="mt-3">Rasulullah S.A.W. said: “Qur’an al-Karim is wisdom. If a person learns the Quran when he is young, Qur’an will mix with his flesh and blood. Beware, verily the hell fire does not touch a heart which is a vessel to contain the Qur’an and a body which regards its Halal as Halal and...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/merits-of-learning-the-quran-al-kareem/">1,875 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Tawfeeq-Success.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/success-comes-from-allah-taala/" rel="bookmark" class="entry-date">
                                          21 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/success-comes-from-allah-taala/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/success-comes-from-allah-taala/">Success Comes From Allah Taala</a>
                              </h4>
                              <p class="mt-3">Khalid bin Walid (Radhiyallahu Anhu), the well-known commander of the Muslim army, was discharged from his duty by Hadhrat Umar (R.A.) in 17 A.H.
After the victory at Humus, when he was informed by Maslama (R.A.) that he was discharged from his office...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/success-comes-from-allah-taala/">1,563 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Month_Of_Shawwal.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-month-of-shawwal/" rel="bookmark" class="entry-date">
                                          14 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-month-of-shawwal/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-month-of-shawwal/">The Month Of Shawwal</a>
                              </h4>
                              <p class="mt-3">Shawwal is the first month of Hajj. Eid Al-Fitr is the first day of Shawwal in which Muslims are recommended to recite Salawat (durud) upon Nabi SAW. fasting in Shawwal for six days is a sort of offering Shukr (thanks)</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-month-of-shawwal/">2,624 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-05-07-01--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/sadaqah-al-fitr-zakat-al-fitr/" rel="bookmark" class="entry-date">
                                          07 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/sadaqah-al-fitr-zakat-al-fitr/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/sadaqah-al-fitr-zakat-al-fitr/">Sadaqah Al Fitr (Zakat Al Fitr)</a>
                              </h4>
                              <p class="mt-3">Sadaqah Al-Fitr is a Wajib (required) charity which is given by Muslims who have Nisab (80.18 gr gold or its equivalent in cash or trade goods) amount of wealth after providing for his basic necessities and who reached the end of Ramadan Sharif.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/sadaqah-al-fitr-zakat-al-fitr/">3,144 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-10--Zayd_ibn_Khattab.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/zayd-ibn-khattab/" rel="bookmark" class="entry-date">
                                          07 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/zayd-ibn-khattab/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/zayd-ibn-khattab/">Zayd ibn Khattab</a>
                              </h4>
                              <p class="mt-3">Muhammad (saw) called him "the best cavalryman". He was afraid of the punishment of Hakk. He was an attentive, intelligent and brave young man. When he was about twenty years old, he secretly researched Islam. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/zayd-ibn-khattab/">2,429 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-09--UkkaYsha_ibn_Mihsan.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/ukkasha-ibn-mihsan/" rel="bookmark" class="entry-date">
                                          05 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/ukkasha-ibn-mihsan/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/ukkasha-ibn-mihsan/">Ukkasha Ibn Mihsan</a>
                              </h4>
                              <p class="mt-3">Muhammad (saw) called him "the best cavalryman". He was afraid of the punishment of Hakk. He was an attentive, intelligent and brave young man. When he was about twenty years old, he secretly researched Islam. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/ukkasha-ibn-mihsan/">2,034 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-08--Abu_Lubaba.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abu-lubaba/" rel="bookmark" class="entry-date">
                                          03 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abu-lubaba/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abu-lubaba/">Abu Lubaba</a>
                              </h4>
                              <p class="mt-3">Abu Lubaba is a member of the Aws tribe from Madinah. In the second Aqaba Pledge, he was honored with Islam. Prophet (saw) appointed him representative to his tribe.He participated in all the battles of Muhammad sallallahu alayhi wa sallam.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abu-lubaba/">2,436 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-07--Abud-Darda.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abud-darda/" rel="bookmark" class="entry-date">
                                          01 May 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abud-darda/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abud-darda/">Abu;d-Darda</a>
                              </h4>
                              <p class="mt-3">He is one of the prominent Companions of the Prophet (pbuh) in the sciences of the Quran, fiqh and hadith. He became a Muslim in the second year after the Migration. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abud-darda/">2,206 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Most_Acceptable_Zakat_And_Sadaqah--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-most-acceptable-zakat-and-sadaqa/" rel="bookmark" class="entry-date">
                                          30 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-most-acceptable-zakat-and-sadaqa/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-most-acceptable-zakat-and-sadaqa/">The Most Acceptable Zakat And Sadaqa</a>
                              </h4>
                              <p class="mt-3">Even though this Ayah was revealed for the Sahaba Suffa, it is for all. All those who learn Ilm for the sake of Allah, who strive in the path of Allah, who devote themselves to service, this Ayah also concerns all these groups of people. These are the best places to give Zakat and Sadaqa to. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-most-acceptable-zakat-and-sadaqa/">2,299 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-06--Abdullah_ibn_Omar.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abdullah-ibn-omar/" rel="bookmark" class="entry-date">
                                          29 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abdullah-ibn-omar/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abdullah-ibn-omar/">Abdullah ibn Omar</a>
                              </h4>
                              <p class="mt-3">Among the most superior in fiqh, tafsir and hadith, Hz. Omar;s son. He was a Companion who was very interested in everything related to the Prophet and was known as the door of all good. His grave is in Muhassab. When his father was honored with Islam, he became a Muslim at a young age. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abdullah-ibn-omar/">2,259 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-05--Hanzalah_ibn_Abi_Amr.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/hanzalah-ibn-abi-amr/" rel="bookmark" class="entry-date">
                                          27 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/hanzalah-ibn-abi-amr/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/hanzalah-ibn-abi-amr/">Hanzalah ibn Abi Amr</a>
                              </h4>
                              <p class="mt-3">One day before the Battle of Uhud, He married Ubay b. Salul;s daughter Jameela, who was a Muslim. When he heard that Muhammad (saw) had gone to Uhud to fight the polytheists of Mecca, he joined the Islamic army without having time to take full ablution...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/hanzalah-ibn-abi-amr/">2,802 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-04--Khabbab_ibn_Al_Aratt.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/khabbab-ibn-al-aratt/" rel="bookmark" class="entry-date">
                                          24 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/khabbab-ibn-al-aratt/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/khabbab-ibn-al-aratt/">Khabbab ibn Al Aratt</a>
                              </h4>
                              <p class="mt-3">Hazrat-i Khabbâb was a blacksmith and made a sword. Our master the Prophet used to go to his shop and meet with him. As a result of these meetings, Hazrat Khabbâb became a Muslim and took the path of eternal peace. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/khabbab-ibn-al-aratt/">2,352 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Excellence_Of_Ramadan_Al-Sharif--500x500_kopya.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif-2/" rel="bookmark" class="entry-date">
                                          23 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif-2/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif-2/">The Excellence Of Ramadan Al-Sharif</a>
                              </h4>
                              <p class="mt-3">A person who just lets the month of Ramadan Sharif go idly without any form of worship, will also let spend the whole year like that. The faithful should discipline themselves spirituality so that they are intent and eager to achieve many good deeds in this blessed month.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif-2/">1,846 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-03--Miqdad_Ibn_Aswad_1.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/miqdad-ibn-aswad/" rel="bookmark" class="entry-date">
                                          21 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/miqdad-ibn-aswad/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/miqdad-ibn-aswad/">Miqdad ibn Aswad</a>
                              </h4>
                              <p class="mt-3">He is better known as al-Miqdad ibn al-Aswad al-Kindi or simply Miqdad, was one of the companions of the Islamic prophet Muhammad. Miqdad lost his hand in the Battle of Badr. Miqdad, who is famous for his courage, came to the Messenger of Allah in the Battle of Badr...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/miqdad-ibn-aswad/">3,012 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-02--Salman_al_Farsi.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/salman-al-farsi/" rel="bookmark" class="entry-date">
                                          18 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/salman-al-farsi/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/salman-al-farsi/">Salman al-Farsi</a>
                              </h4>
                              <p class="mt-3">Salman al-Farsi was the first Persian who converted to Islam. He is credited with the suggestion of digging a trench around Medina, a Sasanian military technique, when it was attacked by Mecca...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/salman-al-farsi/">2,222 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Quran_is_a_shifa--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-holy-quran-is-a-shifa-healing-for-the-faithful/" rel="bookmark" class="entry-date">
                                          15 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-holy-quran-is-a-shifa-healing-for-the-faithful/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-holy-quran-is-a-shifa-healing-for-the-faithful/">The Holy Quran Is A Shifa (Healing) For The Faithful</a>
                              </h4>
                              <p class="mt-3">Quran is a cure for the spiritual ailments. By means of it, people can maintain their spiritual wellbeing, getting rid of superstitions and bad manners. The whole Quran itself and Surah Al-Fatiha has healing properties for a person who has full faith in this.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-holy-quran-is-a-shifa-healing-for-the-faithful/">3,961 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-22--Ashab-Y_Suffa-01--Bilal_al_Habashi.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/bilal-al-habashi/" rel="bookmark" class="entry-date">
                                          14 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/bilal-al-habashi/" rel="bookmark" class="entry-category">
                                          Ashab us-Suffah
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/bilal-al-habashi/">Bilal al Habashi</a>
                              </h4>
                              <p class="mt-3">Bilal ibn Rabah was one of the most trusted and loyal Sahabah (companions) of the Islamic prophet Muhammad (saw). He was born in Mecca and is considered to have been the first mu;azzin, chosen by Muhammad (saw) himself.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/bilal-al-habashi/">3,166 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-12--Zubair_Ibn_Awwam.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/zubayr-ibn-awwam/" rel="bookmark" class="entry-date">
                                          12 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/zubayr-ibn-awwam/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/zubayr-ibn-awwam/">Zubayr Ibn Awwam</a>
                              </h4>
                              <p class="mt-3">He was called "Abu Abdullah" in reference to his oldest son, Abdullah. He was the Prophet;s friend and the son of his aunt Safiyyah binti Abdulmuttalib. After Hazrat Omar;s (ra) death, he was one of the 6-member council established. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/zubayr-ibn-awwam/">2,863 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-11--Talha_Ibn_Ubaidullah.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/talha-ibn-ubaidullah/" rel="bookmark" class="entry-date">
                                          11 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/talha-ibn-ubaidullah/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/talha-ibn-ubaidullah/">Talha Ibn Ubaidullah</a>
                              </h4>
                              <p class="mt-3">Talha was one of the first eight people to accept Islam and one of five people who became Muslim through Abu Bakr. He heroically defended the Prophet at Uhud. Talha was the Rasulullah;s (saw) brother-in-law. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/talha-ibn-ubaidullah/">6,095 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-10--Said_Ibn_Zayd.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/said-ibn-zayd/" rel="bookmark" class="entry-date">
                                          10 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/said-ibn-zayd/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/said-ibn-zayd/">Sa;id Ibn Zayd</a>
                              </h4>
                              <p class="mt-3">His father was Zayd ibn Amr and his genealogy meets with the Prophet;s in Ka;b. His patronymic was Abul-A;var. He was also called Abu Tur. His mother was Fatima binti Ba;ja. His father Zayd belonged to the Haneef religion of Ibrahim.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/said-ibn-zayd/">3,961 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-09--Sad_Ibn_Abi_Waqqas.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/sad-ibn-abi-waqqas/" rel="bookmark" class="entry-date">
                                          09 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/sad-ibn-abi-waqqas/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/sad-ibn-abi-waqqas/">Sa;d Ibn Abi Waqqas</a>
                              </h4>
                              <p class="mt-3">His father was Malik ibn Wuhayb. His patronymic being Abi Waqqas, Sa;d was called Ibn Abi Waqqas due to it. Because the Prophet;s mother was the Banu Zuhra, his genealogy meets the Prophet;s on his mother;s side. Sa;d;s mother was Hamene binti Sufyan ibn Umayya.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/sad-ibn-abi-waqqas/">3,383 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-04-07--Abdurrahman_Ibn_Awf.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abdurrahman-bin-avf/" rel="bookmark" class="entry-date">
                                          07 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abdurrahman-bin-avf/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abdurrahman-bin-avf/">Abdurrahman bin Avf</a>
                              </h4>
                              <p class="mt-3">Abdurrahman bin Awf, who entered Islam during the days of activity in Arkam;s house, was given this name by the Prophet. He joined both migrations to Abyssinia. Eventually, when Muhammad (saw) encouraged the Companions to migrate to Medina, he did so with the others.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abdurrahman-bin-avf/">3,563 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Reward_Of_Feeding_A_Fasting_Muslim.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-reward-of-feeding-a-fasting-muslim/" rel="bookmark" class="entry-date">
                                          02 Apr 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-reward-of-feeding-a-fasting-muslim/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-reward-of-feeding-a-fasting-muslim/">The Reward Of Feeding A Fasting Muslim</a>
                              </h4>
                              <p class="mt-3">Whoever offers Iftar to a fasting person in Ramadan with his Halal (lawfully earned) income, all the angels will make Istighfar (ask forgiveness) on his behalf at nights during Ramadan. When it is the Night of Qadr, Jibrail Alayhis Salâm makes musafaha (shakes hands) with him.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-reward-of-feeding-a-fasting-muslim/">2,175 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/04-Ali-Ibn-Abi-Talib.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/ali-ibn-abi-talib/" rel="bookmark" class="entry-date">
                                          31 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/ali-ibn-abi-talib/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/ali-ibn-abi-talib/">Ali Ibn Abi Talib</a>
                              </h4>
                              <p class="mt-3">Ali was the son of the Prophet;s uncle, his son-in-law and the fourth caliph. He was constantly at the side of the Prophet, he was advanced in Tafsir, Hadith and Fiqh. In fact, in the Prophet;s words he was the "gate to the city of knowledge", the most knowledgeable of the community.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/ali-ibn-abi-talib/">3,582 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Virtue_Of_The_Baraat_kopya.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-virtue-of-the-night-of-the-baraat/" rel="bookmark" class="entry-date">
                                          25 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-virtue-of-the-night-of-the-baraat/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-virtue-of-the-night-of-the-baraat/">The Virtue Of The Night Of The Baraat</a>
                              </h4>
                              <p class="mt-3">Some of the attributes of the night of Baraat: Every action – the Rizq of people, their fates and important actions - are decided and written on this night. To pray on this night is very rewarding. Mercy rains on this night. Believers are forgiven, their sins erased.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-virtue-of-the-night-of-the-baraat/">2,712 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-03-21--Uthman-Ibn-Affan--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/uthman-ibn-affan/" rel="bookmark" class="entry-date">
                                          21 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/uthman-ibn-affan/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/uthman-ibn-affan/">Uthman Ibn Affan</a>
                              </h4>
                              <p class="mt-3">A monument of modesty, he is the third Rightly-Guided Caliph. His patronymic is Uthman ibn Affan. After he became Muslim, married Hazrat Ruqayya (r.anha), the Prophet;s (s.a.w) daughter, and had a son named Abdullah, he became known as "Abu Abdullah." </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/uthman-ibn-affan/">3,017 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-03-18--Omar-Ibn-Khattab_-500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/omar-bin-khattab/" rel="bookmark" class="entry-date">
                                          18 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/omar-bin-khattab/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/omar-bin-khattab/">Omar Bin Khattab</a>
                              </h4>
                              <p class="mt-3">Deciding to kill the Prophet Muhammad (pbuh), Omar girthed his sword and set out to kill him. However, when he learned that his sister and her husband had entered the new religion, he went to them first and, affected by the Quranic verses they read, he accepted Islam.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/omar-bin-khattab/">3,348 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-03-19-01--500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/following-the-sahaba-the-companions/" rel="bookmark" class="entry-date">
                                          18 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/following-the-sahaba-the-companions/" rel="bookmark" class="entry-category">
                                          Sahabah (The Companions)
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/following-the-sahaba-the-companions/">Following The Sahaba (The Companions)</a>
                              </h4>
                              <p class="mt-3">Each sects, among the seventy-three (declared in a Hadith Shareef), claim that they are the true followers of the Shari`ah and they firmly believe that they are among the sect to be saved from fire. The Ayah that translates: “Each group rejoicing in its circle. (Surah Rum, 32)” testify their situations.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/following-the-sahaba-the-companions/">3,019 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/00-Ashara_Mubashara.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/ashara-mubashara-the-blessed-companions-2/" rel="bookmark" class="entry-date">
                                          15 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/ashara-mubashara-the-blessed-companions-2/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/ashara-mubashara-the-blessed-companions-2/">Ashara Mubashara (The Blessed Companions)</a>
                              </h4>
                              <p class="mt-3">The Islamic prophet, Muhammad (s.a.w.), specified ten of his companions who were promised paradise. The companions named in this hadith are referred to as "The Ten With Glad Tidings of Paradise". The hadith is collected in two of the six books of the Kutub al-Sittah: the Jamiʿ at-Tirmidhi and the Sunan Abu Dawood.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/ashara-mubashara-the-blessed-companions-2/">78,567 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2021-03-15--Abu-Bakr-As-Siddiq-500x500_1.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abu-bakr-as-siddiq/" rel="bookmark" class="entry-date">
                                          15 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abu-bakr-as-siddiq/" rel="bookmark" class="entry-category">
                                          Ashara Mubashara 
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abu-bakr-as-siddiq/">Abu Bakr As-Siddiq</a>
                              </h4>
                              <p class="mt-3">His original name was Abdul-Kaaba. After the advent of Islam, the Prophet gave him the name of Abdullah. His patronymic is Abu Bakr. He is known with the sobriquets of Jamiul Quran, as-Siddiq, and al-Atiq. The most famous of these is as-Siddiq.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abu-bakr-as-siddiq/">3,727 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Virtues_Of_Month_Of_Shaban.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-virtues-of-the-month-of-shaban/" rel="bookmark" class="entry-date">
                                          11 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-virtues-of-the-month-of-shaban/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-virtues-of-the-month-of-shaban/">The Virtues Of The Month Of Sha;ban</a>
                              </h4>
                              <p class="mt-3">This is a month in which the doors of good are opened, abundance is given, mistakes are left, sins are forgiven, and Salawat towards the most perfect of all creations, Rasulullah (s.a.w.) should be recited. Believers should awaken in this month and see it as an opportunity to repent from their sins and enter the month of Ramadan in a clean state.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-virtues-of-the-month-of-shaban/">3,369 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Ulama__500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/ilm-knowledge-will-not-disappear-till-the-day-of-qiyamah/" rel="bookmark" class="entry-date">
                                          05 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/ilm-knowledge-will-not-disappear-till-the-day-of-qiyamah/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/ilm-knowledge-will-not-disappear-till-the-day-of-qiyamah/">Ilm (Knowledge) Will Not Disappear Till The Day Of Qiyamah</a>
                              </h4>
                              <p class="mt-3">Harith Bin Umayra (Radhiyallahu Anhu), who was in the service of Muadh Bin Jabal (Radhiyallahu Anhu), narrated: During the sickness which caused Muadh (Radhiyallahu Anhu’s) death, he was fainting and regaining his consciousness.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/ilm-knowledge-will-not-disappear-till-the-day-of-qiyamah/">2,198 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Sayfa_Iconu.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/worshipping-at-night/" rel="bookmark" class="entry-date">
                                          04 Mar 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/worshipping-at-night/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/worshipping-at-night/">THE SITUATIONS THAT HINDERS ONE FROM WORSHIPPING AT NIGHT</a>
                              </h4>
                              <p class="mt-3">Our Prophet (Sallallahu Alayhi Wa Sallam) said, “I advise you to continue to worship at night, for it was your pious predecessors’ tradition. And indeed, night prayer draws you closer to Allah, restrains you from sins, expiates for the (past) sins and it is a Shifa (cure) for the bodily ailments.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/worshipping-at-night/">2,096 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Tawba_and_Istighfaar--500x500_1.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/do-not-despair-of-allahs-mercy/" rel="bookmark" class="entry-date">
                                          26 Feb 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/do-not-despair-of-allahs-mercy/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/do-not-despair-of-allahs-mercy/">Do Not Despair Of Allah;s Mercy</a>
                              </h4>
                              <p class="mt-3">In the 53rd Ayah of Surah Al-Zumar Allah (S.W.T.) says: ‘‘…Oh my slaves who have transgressed against themselves! Despair not of the mercy of Allah! Verily Allah forgives all sins.’’ Some scholars claim that this ayah is the only ayah that gives hope to the desperate.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/do-not-despair-of-allahs-mercy/">3,396 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Salah_Al_Shukr-400x400.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/salah-al-shukr-thankfulness/" rel="bookmark" class="entry-date">
                                          19 Feb 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/salah-al-shukr-thankfulness/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/salah-al-shukr-thankfulness/">Salah Al-Shukr (Thankfulness)</a>
                              </h4>
                              <p class="mt-3">After the Lailatul Raghaib (Friday), between Jumuah and Asr Salâh, one should pray a four rakah Salah Al-Shukr (thankfulness): Every two rakah is marked with a salam. In each rakah, 7 times Ayah Al- Kursi, 5 times Surah Al-Ikhlas , 5 times Surah Al-Falaq and...</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/salah-al-shukr-thankfulness/">11,496 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Regaib_Salah-500x500.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-night-of-raghaib-and-ibadah-advised-for-the-night/" rel="bookmark" class="entry-date">
                                          18 Feb 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-night-of-raghaib-and-ibadah-advised-for-the-night/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-night-of-raghaib-and-ibadah-advised-for-the-night/">The Night Of Raghaib And Ibadah Advised For The Night</a>
                              </h4>
                              <p class="mt-3">The first Friday night of Rajab Sharîf is called the Night of Raghâ’ib. Muslims should enter this holy night fasting. Muslims are advised to perform a Hajah Salâh (Salâh of needs), consisting of 12 Rakâhs on this night between Maghrib and Ishâ Salâh.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-night-of-raghaib-and-ibadah-advised-for-the-night/">2,169 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Hajah_Salah_400x400.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/salah-al-hajah-in-the-month-of-rajab/" rel="bookmark" class="entry-date">
                                          11 Feb 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/salah-al-hajah-in-the-month-of-rajab/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/salah-al-hajah-in-the-month-of-rajab/">Salah Al-Hajah In The Month Of Rajab</a>
                              </h4>
                              <p class="mt-3">There is a Hajah Salah that is performed in the first, second, and the last ten days of Rajab Al-Sharif consisting of 10 Rak’ah . Their performance is the same for every ten days. They can be performed after Maghrib or Isha Salah. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/salah-al-hajah-in-the-month-of-rajab/">3,975 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Excellence_Of_Ramadan_Al-Sharif.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif/" rel="bookmark" class="entry-date">
                                          11 Feb 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif/">The Excellence Of Ramadan Al-Sharif</a>
                              </h4>
                              <p class="mt-3">The month of Ramadan is superior to all other months. Any Nafilah ibadah fulfilled in this month is equal to the Fardh deeds fulfilled in other months. Whoever accomplishes one Fardh deed in Ramadan, will be rewarded as if he accomplishes seventy Fardh deeds in other months. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-excellence-of-ramadan-al-sharif/">2,099 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Rajab_Shareef-400x400.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/rajab-shareef-the-month-of-allah-shahrullah/" rel="bookmark" class="entry-date">
                                          04 Feb 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/rajab-shareef-the-month-of-allah-shahrullah/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/rajab-shareef-the-month-of-allah-shahrullah/">Rajab Shareef, The Month of Allah (Shahrullah)</a>
                              </h4>
                              <p class="mt-3">The month of Rajab which we will enter is the seventh month of the Hijra calendar. It is part of ‘Ash’hur al hurum’ and is Shahrullah, meaning the month of Allah. A person should fast in this month and ask for forgiveness.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/rajab-shareef-the-month-of-allah-shahrullah/">7,264 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Virtue_Of_Places_Of_Knowledge.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-virtue-of-places-of-knowledge/" rel="bookmark" class="entry-date">
                                          28 Jan 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-virtue-of-places-of-knowledge/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-virtue-of-places-of-knowledge/">The Virtue Of Places Of Knowledge</a>
                              </h4>
                              <p class="mt-3">Hz. Abu Lays al Samarqandi said: <br> 
"Seven virtues a person will gain by being present in a place of knowledge (Ilm) even if they do not learn anything:..."</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-virtue-of-places-of-knowledge/">1,968 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Duties-Of-Parents-400x400.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/duties-of-parents/" rel="bookmark" class="entry-date">
                                          23 Jan 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/duties-of-parents/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/duties-of-parents/">Duties Of Parents</a>
                              </h4>
                              <p class="mt-3">Importance should be given to the education of their children. When their child reaches the age of 6, the parents should teach them the Qur’an, the Fardh and manners of Islam. Parents should be very merciful towards their children. They should kiss them and hug them. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/duties-of-parents/">1,899 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/uthman-masjid-building.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/uthman-radiyallahu-anhu-extends-masjid-al-nabawi/" rel="bookmark" class="entry-date">
                                          14 Jan 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/uthman-radiyallahu-anhu-extends-masjid-al-nabawi/" rel="bookmark" class="entry-category">
                                          Sahabah (The Companions)
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/uthman-radiyallahu-anhu-extends-masjid-al-nabawi/">Uthman (Radiyallahu Anhu) Extends Masjid Al-Nabawi</a>
                              </h4>
                              <p class="mt-3">The further Islam spread the more Muslims began to visit Madinah Al-Munawwarah. When there was not enough space to accommodate all in the masjid, Muslims began to put up their own tents in the open and make their Salah there.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/uthman-radiyallahu-anhu-extends-masjid-al-nabawi/">2,023 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/To-Give-Salaam.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/to-give-salaam/" rel="bookmark" class="entry-date">
                                          07 Jan 2021
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/to-give-salaam/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/to-give-salaam/">To Give Salaam</a>
                              </h4>
                              <p class="mt-3">The person who greets his fellow Muslim brother is rewarded by Allâh Ta‘âlâ as if he has freed a slave. Salaam, if practiced regularly, removes the negative feeling of hatred and grudges hidden in the heart; it eliminates hostility and estrangement and forms a sincere bond of brotherhood.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/to-give-salaam/">2,041 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/The_Reward_Of_Doing_Good_For_The_Sake_Of_Allah.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-reward-of-doing-good-for-the-sake-of-allah/" rel="bookmark" class="entry-date">
                                          31 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-reward-of-doing-good-for-the-sake-of-allah/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-reward-of-doing-good-for-the-sake-of-allah/">The Reward Of Doing Good For The Sake Of Allah</a>
                              </h4>
                              <p class="mt-3">Abu Hamza Muhammad bin Ibrahim (Rahmatullahi Alayhi), one of the Ustadh’s (teachers) of Junaid Al-Baghdadi (r.a.), had a child born to him on a rainy night. They had nothing to eat at home that night. </p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-reward-of-doing-good-for-the-sake-of-allah/">1,967 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Tasabbuh_1.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/tasabbuh-trying-to-resemble/" rel="bookmark" class="entry-date">
                                          24 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/tasabbuh-trying-to-resemble/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/tasabbuh-trying-to-resemble/">Tasabbuh: Trying To Resemble</a>
                              </h4>
                              <p class="mt-3">Tashabbuh is resembling a person in his physical look, living style, character, quality or habits, or imitating another person to look like him.
Rasulullah said: ‘‘Whoever loves and befriends a people, Allah Ta’ala raises him that day among them.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/tasabbuh-trying-to-resemble/">1,876 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Seeking-Knowledge-Islamic-Education.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/seeking-knowledge-of-ilm-al-hal-is-fardh-upon-every-muslim/" rel="bookmark" class="entry-date">
                                          17 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/seeking-knowledge-of-ilm-al-hal-is-fardh-upon-every-muslim/" rel="bookmark" class="entry-category">
                                          Islamic Education
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/seeking-knowledge-of-ilm-al-hal-is-fardh-upon-every-muslim/">Seeking Knowledge Of Ilm Al-Hal Is Fardh Upon Every Muslim</a>
                              </h4>
                              <p class="mt-3">Every Muslim need to teach their families Ilm Al-Hal and safeguard them from all that which do not comply with Islam. The same is true for one’s all dependants. Firstly, they need to teach them about the belief of Ahl Al-Sunnah, then the Fiqh knowledge, Akhlaq, and Muamalat such as trade. To know all the mentioned is Fardh Al-Ayn.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/seeking-knowledge-of-ilm-al-hal-is-fardh-upon-every-muslim/">3,281 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/2020-12-14-02.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/abdurrahman-bin-awf-and-his-generosity/" rel="bookmark" class="entry-date">
                                          15 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/abdurrahman-bin-awf-and-his-generosity/" rel="bookmark" class="entry-category">
                                          Sahabah (The Companions)
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/abdurrahman-bin-awf-and-his-generosity/">Abdurrahman bin Awf and His Generosity</a>
                              </h4>
                              <p class="mt-3">In the age of Jahiliyya, Abdurrahman bin Awf was known as an honest person who did not drink alcohol and had good morals. His old friendship with Abu Bakr enabled him to become a Muslim thanks to him.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/abdurrahman-bin-awf-and-his-generosity/">4,828 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Caring-to-Pray.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/caring-to-pray-fajr-and-isha-salah-in-jamaah/" rel="bookmark" class="entry-date">
                                          11 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/caring-to-pray-fajr-and-isha-salah-in-jamaah/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/caring-to-pray-fajr-and-isha-salah-in-jamaah/">Caring To Pray Fajr And Isha Salah In Jama;ah</a>
                              </h4>
                              <p class="mt-3">Ashab Al-Kiram (the noble companions) paid great care in performing Fajr and Isha Salah in Jama’ah. It is because, Rasûlullâh (S.A.W) said: “Indeed, two Salah are the most burdensome on the Munafiqs. They are Fajr and Isha. Had they known about their rewards; they would have hastened to (perform) them.”</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/caring-to-pray-fajr-and-isha-salah-in-jamaah/">2,779 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/To_Give_From_The_Best.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/to-give-from-the-best/" rel="bookmark" class="entry-date">
                                          06 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/to-give-from-the-best/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/to-give-from-the-best/">To Give From The Best</a>
                              </h4>
                              <p class="mt-3">One Ayah of Surah Ali Imran, that reads “You cannot attain Al-Birr (real goodness) unless you give from what you love must.” was revealed. After that, Abu Talha (R.A.) came to Nabi (S.A.W.) an said: “O prophet of Allah! (S.A.W.).</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/to-give-from-the-best/">1,875 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Reading_Benefical_Book.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/reading-benefical-books/" rel="bookmark" class="entry-date">
                                          04 Dec 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/reading-benefical-books/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/reading-benefical-books/">Reading Benefical Books</a>
                              </h4>
                              <p class="mt-3">A nation that does not feed the growing minds, the youth, with proper and beneficial books then such youth will become corrupt. Books show the spiritual and physical realities to people like light houses even in the dark eras.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/reading-benefical-books/">2,425 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/acquiring_knowledge.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/acquiring-knowledge/" rel="bookmark" class="entry-date">
                                          27 Nov 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/acquiring-knowledge/" rel="bookmark" class="entry-category">
                                          About Ilm Or Seeking Knowledge
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/acquiring-knowledge/">Acquiring Knowledge</a>
                              </h4>
                              <p class="mt-3">Each Muslim should know the rulings and requirements of Islam. <br>If Allah (S.W.T.) wishes good for an ummah, He bestows knowledge to their rulers and wealth to their ulama (scholars).</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/acquiring-knowledge/">2,598 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/near-mosque-america.png">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-gardens-of-jannah-paradise-are-the-masajid-mosques/" rel="bookmark" class="entry-date">
                                          19 Nov 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-gardens-of-jannah-paradise-are-the-masajid-mosques/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-gardens-of-jannah-paradise-are-the-masajid-mosques/">The Gardens Of Jannah (Paradise) Are The Masajid (Mosques</a>
                              </h4>
                              <p class="mt-3">Every Masjid has a great virtue and honour. In order to indicate this honour, they are called ‘Baytullah’ (house of Allah). Thus, they deserve due respect.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-gardens-of-jannah-paradise-are-the-masajid-mosques/">2,545 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/knonledge-deeds-sincerity.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/knowledge-deeds-and-sincerity/" rel="bookmark" class="entry-date">
                                          13 Nov 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/knowledge-deeds-and-sincerity/" rel="bookmark" class="entry-category">
                                          About Ilm Or Seeking Knowledge
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/knowledge-deeds-and-sincerity/">Knowledge, Deeds And Sincerity</a>
                              </h4>
                              <p class="mt-3">Indeed Islamic Canonical Law is of three parts: Ilm (knowledge), amal (deeds) and ikhlas (sincerity). Shari’ah will not be established unless each of these three parts is practised.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/knowledge-deeds-and-sincerity/">1,902 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Share-A-Gift-Fazilet-Calendar-Bundle2.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/one-form-of-charity-is-to-give-gifts/" rel="bookmark" class="entry-date">
                                          06 Nov 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/one-form-of-charity-is-to-give-gifts/" rel="bookmark" class="entry-category">
                                          Social Life
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/one-form-of-charity-is-to-give-gifts/">One Form Of Charity Is To Give Gifts</a>
                              </h4>
                              <p class="mt-3">Gift increases love, affection and intimacy among people in social life; It is an important sunnah that removes resentment and distances between them. Giving complimentary gifts, especially according to the needs, curiosity and desires of people, is a means of both worldly and otherworldly gains.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/one-form-of-charity-is-to-give-gifts/">3,859 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/the-virtue-of-salawat-al-sharifa-on.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/the-virtue-of-salawat-al-sharifa/" rel="bookmark" class="entry-date">
                                          29 Oct 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/the-virtue-of-salawat-al-sharifa/" rel="bookmark" class="entry-category">
                                          Blog
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/the-virtue-of-salawat-al-sharifa/">The Virtue Of Salawat Al-Sharifa</a>
                              </h4>
                              <p class="mt-3">Sayyiduna Ali (karram Allahu wajhah) said: ‘Rasulullah (S.A.W.) said’: “Indeed Allah (S.W.T.) has some appointed angels that descend on earth only on Fridays during the day and night. They have golden pens, silver inkwells and papers of light in their hands.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/the-virtue-of-salawat-al-sharifa/">4,758 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>
  
<div class="col-lg-4 col-md-6 xs-journal-wrapper">
  <div class="xs-box-shadow xs-single-journal xs-mb-30">
      <div class="col-lg-12 p-0 xs-single-journal-container">
          <div>
                          <div class="entry-thumbnail ">
                              <img src="https://uama.us//d_genel/Mevlid2_1.jpg">
                          </div><!-- .xs-item-header END -->
                          <div class="entry-header">
                              <div class="entry-meta d-flex justify-content-between">
                                  <span class="date">
                                      <a href="https://uama.us/en/night-of-mawlid/" rel="bookmark" class="entry-date">
                                          10 Oct 2020
                                      </a>
                                  </span>
                                  <span class="category">
                                      <a href="https://uama.us/en/night-of-mawlid/" rel="bookmark" class="entry-category">
                                          Important Days and Nights
                                      </a>
                                  </span>
                              </div>
                              
                              <h4 class="entry-title">
                                  <a href="https://uama.us/en/night-of-mawlid/">Mawlid Al Nabi</a>
                              </h4>
                              <p class="mt-3">Night of Mawlid is the night Rasulullah (Sallallahu Alayhi Wa Sallam) honoured the whole universe with his coming.
Rasulullah (Sallallahu Alayhi Wa Sallam) honoured the whole universe with his arrival on the 12th night of Rabi’ al Awwal on a Monday. Thus, the 12th night of Rabi’ al Awwal is the a sacred night in the Hijri Calendar.</p>
                          </div><!-- .xs-entry-header END -->
                      </div>
                      <div class="post-meta meta-style-color">
                          <span class="view-link">
                              <i class="fa fa-eye"></i>
                              <a href="https://uama.us/en/night-of-mawlid/">4,328 Views</a>
                          </span>
                      </div><!-- .post-meta END -->
                  </div>
  </div><!-- .xs-from-journal END -->
</div>

</div>';