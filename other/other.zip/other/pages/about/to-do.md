redirect listesi olustur
eski redireckleri sitede aktar 
cacheleri hizli alabilmesi icin bir eklenti yaz ve curl ile url lerde gezinsin 
wb form db - wpforms icine alinabilir mi buna bakilacak -- bu eklenti oldugu icin update de eski yerine gelir buna bir cozum 
