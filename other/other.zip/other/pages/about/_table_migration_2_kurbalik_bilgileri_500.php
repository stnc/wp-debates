<?php


function dateMan($receiveData)
{

  // 05.17.2022 17:45:04--gelen  ay gun  yil 

  // return 	2022-05-17 17:45:04  - yil ay gun 

  // $receiveData="05.17.2022 17:45:04";




  $pieces = explode(" ", $receiveData);
  $pieces[0]; // piece1
  $pieces[1]; // piece2

  $dateSection = $pieces[0];
  $dateSectionPieces = explode(".", $dateSection);

  return $newDate = $dateSectionPieces[2] . "-" . $dateSectionPieces[0] . "-" . $dateSectionPieces[1] . " " . $pieces[1];


}




function issuedDate($receiveData)
{

  // 05.17.2022 17:45:04--gelen  ay gun  yil 

  return // 	2022-05-17 


  $pieces = explode(" ", $receiveData);
  $pieces[0]; // piece1
  $pieces[1]; // piece2

  $dateSection = $pieces[0];
  $dateSectionPieces = explode(".", $dateSection);

  return $newDate = $dateSectionPieces[2] . "-" . $dateSectionPieces[0] . "-" . $dateSectionPieces[1];


}


function getGenarateName($n)
{
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $randomString = '';

  for ($i = 0; $i < $n; $i++) {
    $index = rand(0, strlen($characters) - 1);
    $randomString .= $characters[$index];
  }

  return $randomString;
}


function branch($branch)
{
  $id = 0;
  if ($branch == "ISABET ACADEMY (A)") {
    $id = 958;
  } else if ($branch == "SULEYMANIYE ACADEMY") {
    $id = 961;
  } else if ($branch == "Dominik Suleymaniye Madrasa") {
    $id = 985;
  } else if ($branch == "Montreal Kırklar Madrasa") {
    $id = 977;
  } else if ($branch == "Edmonton Selimiye Madarasa") {
    $id = 979;
  } else if ($branch == "FATIH ACADEMY") {
    $id = 966;
  } else if ($branch == "YOUNGSTOWN SADABAT EDUCATION CENTER") {
    $id = 968;
  } else if ($branch == "BEDIA SULTAN EDUCATION CENTER") {
    $id = 972;
  } else if ($branch == "Guatemala Suleymaniye Madrasa") {
    $id = 984;
  } else if ($branch == "Toronto Fatih Mosque") {
    $id = 976;
  } else if ($branch == "LOS ANGELES HISAR EDUCATION CENTER") {
    $id = 954;
  } else if ($branch == "Panama") {
    $id = 6466;
  } else if ($branch == "United American Muslim Association") {
    $id = 980;
  } else if ($branch == "Vancouver Eyup Sultan Masjid And Madrasah") {
    $id = 978;
  } else if ($branch == "Al-Bukhari Islamic Center") {
    $id = 971;
  } else if ($branch == "Bereket USA") {
    $id = 988;
  } else if ($branch == "CHICAGO ACADEMY") {
    $id = 969;
  } else if ($branch == "ROCHESTER EDUCATION CENTER") {
    $id = 960;
  } else if ($branch == "New Jersey") {
    $id = 6469;
  } else if ($branch == "WASHINGTON SÜLEYMANİYE") {
    $id = 6472;
  } else if ($branch == "CONNECTICUT MEVLANA EDUCATION CENTER") {
    $id = 967;
  } else if ($branch == "NY-Valide-Sultan") {
    $id = 6474;
  } else if ($branch == "YOUNGSTOWN SADABAT EDUCATION CENTER") {
    $id = 968;
  }
  return $id;
}
function userID($user)
{
  if ($user == "(Yunus) Gungor Bektas") {
    $id = 93;
  } else if ($user == "Adnan Çınar") {
    $id = 155;
  } else if ($user == "Aibek Jamalov") {
    $id = 165;
  } else if ($user == "Ali Onut") {
    $id = 131;
  } else if ($user == "Alihan Karyagdi") {
    $id = 170;
  } else if ($user == "Bilal Ezer") {
    $id = 106;
  } else if ($user == "Cihat Yıldız") {
    $id = 171;
  } else if ($user == "Emrah incekan") {
    $id = 172;
  } else if ($user == "Enes Fatih İmre") {
    $id = 96;
  } else if ($user == "Furkan Akca") {
    $id = 173;
  } else if ($user == "hasan Otken") {
    $id = 127;
  } else if ($user == "İlyas Yılmaz") {
    $id = 76;
  } else if ($user == "İskender Büyüksoylu") {
    $id = 112;
  } else if ($user == "Kemal Tarik Ozer") {
    $id = 144;
  } else if ($user == "Mahmut Turk") {
    $id = 174;
  } else if ($user == "Mehmet Deniz") {
    $id = 164;
  } else if ($user == "Mehmet Fatih Keskinsoy") {
    $id = 115;
  } else if ($user == "Mehmet Sarıboga") {
    $id = 168;
  } else if ($user == "Mesut Paca") {
    $id = 166;
  } else if ($user == "Muhsin Yildiz") {
    $id = 113;
  } else if ($user == "Mumtaz Kecelioglu") {
    $id = 61;
  } else if ($user == "Musa Turan") {
    $id = 100;
  } else if ($user == "Mustafa Tunahan Sengul") {
    $id = 158;
  } else if ($user == "Nuri Sener") {
    $id = 117;
  } else if ($user == "Omer Faruk Gunay") {
    $id = 51;
  } else if ($user == "Recep Ozdemir") {
    $id = 134;
  } else if ($user == "Recep Şakrak") {
    $id = 134;
  } else if ($user == "Selman Yuce") {
    $id = 72;
  } else if ($user == "Sencer Cucuk") {
    $id = 49;
  } else if ($user == "Sercan Kaliyev") {
    $id = 78;
  } else if ($user == "Süleyman Emanet") {
    $id = 111;
  } else if ($user == "Suleyman OZ") {
    $id = 133;
  } else if ($user == "Taha Sentürk") {
    $id = 114;
  } else if ($user == "Talha Orhan") {
    $id = 70;
  } else if ($user == "Tevfik Aktar") {
    $id = 135;
  } else if ($user == "Ugur Alayont") {
    $id = 130;
  } else if ($user == "Yakup Saka") {
    $id = 62;
  } else if ($user == "Yasin Karisoglu") {
    $id = 125;
  } else if ($user == "Yasin Karisoglu") {
    $id = 125;
  } else if ($user == "Yasin Suyum") {
    $id = 175;
  } else if ($user == "Arif Ahmet Bilal Bayındır") {
    $id = 59;
  } else if ($user == "Arif Ahmet Bilal Bayındır") {
    $id = 59;
  }
  return $id;
}

function orign_tip($tip)
{
  $tid = 0;
  if ($tip == "Türk") {
    $tid = 1;
  }

  if ($tip == "Gayr-ı Türk") {
    $tid = 2;
  }
  return $tid;
}

function attorney_status($tip)
{
  $tid = 0;
  if ($tip == "Evet") {
    $tid = 2;
  }

  if ($tip == "Hayır") {
    $tid = 1;
  }
  return $tid;
}

function affi_tip($tip)
{
  $tid = 0;
  if ($tip == "Muhibban") {
    $tid = 2;
  }

  if ($tip == "İhvan/Ahavat") {
    $tid = 1;
  }

  if ($tip == "Muhtelif Kominiteler") {
    $tid = 4;
  }

  if ($tip == "Velî") {
    $tid = 3;
  }
  if ($tip == "Personel") {
    $tid = 5;
  }

  return $tid;
}

function mesaj_tip($tip)
{
  $tid = 0;
  if ($tip == "İngilizce Mesaj-Talebe Kurbanı") {
    $tid = 12;
  }

  if ($tip == "İngilizce Mesaj-Yurtdisi Kurbanı") {
    $tid = 10;
  }

  if ($tip == "0- Türkçe Mesaj - Yurtdisi Kurbani") {
    $tid = 10;
  }
  if ($tip == "Türkçe Mesaj - Talebe Kurbanı") {
    $tid = 11;
  }

  if ($tip == "Türkçe Mesaj - Sahis Hisse") {
    $tid = 12;
  }

  if ($tip == "Canada - İngilizce Mesaj-Sahıs Hisse") {
    $tid = 12;
  }

  return $tid;
}
function uama_wp_branch_about()
{


  if (!current_user_can('manage_options')) {
    return;
  }


  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1> Ekranlar Bilinmesi Gerekenler</h1>
    <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;">



      <strong>Eklentinin Kullanımı</strong>


    </div>

  </div>

  OdemelerGeciciDurum = 1 ///TODO: onemli diger durumlar silindi gerekirse durum eklemek icin, burasi rezerve
  OdemelerDurumIkiGrupYerDegistirdi = 3 // iki grup arasi degisim yapildi --- // TODO : iptal burada olmamali belki
  kurbanda olabilir, belki burada durmasinin zarari olmaz
  OdemelerBorcDurumIlkEklenenFiyat = 1 // ilk eklenen fiyat değeri
  OdemelerBorcDurumTaksitOdemesi = 2 // taksit eklemiş
  OdemelerBorcDurumKasaBorcluDurumda = 3 // kasa borçlu kalmışsa---TODO: burada event surekli degisir bu mantikli mi
  kontrol edilmeli
  OdemelerBorcDurumKaporaOdemesiHayvanBos = 4 // kapora odendi ama hayvan atanmamışdır
  OdemelerBorcDurumKaporaOdemesiHayvanVar = 5 // kapora odendi ve hayvan atanmışdır
  OdemelerBorcDurumIkiGrupYerDegistirdi = 5 // iki grup arasi degisim yapildi --- iptal burada olmamali belki durumda
  olabilir
  OdemelerBorcDurumHesapKapandi = 6 // tüm borcunu ödemiş
  OdemelerBorcDurumHicOdemeYapmadi = 7 // hic odeme yapmamis hizli ekleme gibi durumlar
  //OdemelerBorcDurumHayvanKesildi = 7 // hayvan kesildi
  //OdemelerBorcDurumHayvanKesildiTeslimEdildi = 8 // hayvan kesildi teslim edildi
  OdemelerBorcDurumFiyatManuelDegistirildiEsitFiyat = 9 // kurbanın düzenleme alanında fiyatı değiştirilmiş
  OdemelerBorcDurumFiyatManuelDegistirildiYuksekFiyat = 10 // kurbanın düzenleme alanında fiyatı değiştirilmiş
  OdemelerBorcDurumFiyatManuelDegistirildiDusukFiyat = 11 // kurbanın düzenleme alanında fiyatı değiştirilmiş
  //OdemelerBorcDurumHayvanEklendi = 12 // hayvanEklemesi yapılmış
  OdemelerBorcDurumTaksitSilindi = 13 // taksit silindi
  OdemelerBorcDurumTaksitSilindiBildirim = 14 // taksit silindi rapor alanı içindir







  /************************************/
  /**********Kurbanlar DURUM BİLGİLERİ ********/
  /************************************/
  //KurbanDurumKurbanEklendiKurbanBayraminaAitDegil = 10 // kurban eklenmiş ama hisseli yada kurban bayramina ait olmayan
  kucukbas
  KurbanDurumKurbanGirisKaydiYapildi = 1 // giris kaydi
  KurbanDurumGrupOlusmusKurbanYok = 2 // grup oluşmuş ama kimse atanmamış , yani kesimlik kurban verilmemiştir
  KurbanDurumGrupOlusmusKesimlikHayvaniVar = 3 // grup atanmış yani bir kesimlik inek verilmiş
  KurbanDurumKurbanKesimiTamamlanmis = 4 // kurban kesimi tamamlanmış
  KurbanDurumKurbanParcalamaTaksimatta = 5 // kurban kesimi tamamlanmış Kurban Parcalama Taksimatta
  KurbanDurumSevkEdiliyor = 6 // teslim edilmek icin hazirlaniacak
  KurbanDurumTeslimatNoktasinda = 7 // teslimat yeri gelmis
  KurbanDurumKurbanKesildiTeslimEdildi = 7 // kurban kesildi teslim edildi
  KurbanDurumKurbanKesildiTeslimEdilemedi = 8 // kurban kesildi teslim edilemedi
  KurbanKaydiSilindi = 9 // kurban bilgisi silinmis TODO: soft delete kontrol

  //KurbanDurumIkiGrupYerDegistirdi = 5 // iki grup arasi degisim yapildi i //TODO: ayri bir alan olabilir mi aslinda
  olmali

  /************************************/
  /********** BORCLAR **BORC DURUM ********/
  /************************************/
  KurbanBorcDurumIlkEklenenFiyat = 1 // ilk eklenen fiyat değeri
  KurbanBorcDurumKasaBorcluDurumda = 2 // kasa borçlu kalmışsa
  KurbanBorcDurumBorcuDevamEdiyor = 3 // borcu devam ediyor , taksit yada kapora gibi bir ekleme olmussa bu durum
  isaretlenir
  KurbanBorcDurumHesapKapandi = 4 // tüm borcunu ödemiş
  KurbanBorcDurumKaporaOdemesiHayvanBos = 5 // kapora odendi ama hayvan atanmamışdır yani bos grup olusmus daha hayvan
  verilmemesi fakat hayirsever on odeme yapmis

  //KurbanBorcDurumIkiGrupYerDegistirdi = 5 // iki grup arasi degisim yapildi //TODO: ayri bir alan olabilir mi aslinda
  olmali

  //KurbanBorcDurumTaksitSilindi = 11 // taksit silndi //TODO: taksit durum mu bu sadece odemelerde mi tutulsa odeme event
  surekli degisir burada cok degisim olmaz

  /************************************/
  /********** Vekalet ********/
  /************************************/
  VekaletDurumuAlinmadi = 1
  VekaletDurumuAlindi = 2




  //****kisi degisiklik kilidi -- kisi odeme yapmissa artik o kurbandaki kisi bilgileri degistirilmez onun icin onlem
  KisiDegisiklikKilidiKisiDegistirilemez = 0
  KisiDegisiklikKilidiKisiDegistirilebilir = 1


  KurbanTuruAdak = 1
  KurbanTuruAkika = 2
  KurbanTuruSukur = 3
  KurbanTuruNiyet = 4
  KurbanTuruBagis = 5
  KurbanTuruNafile = 6
  KurbanTuruSifa = 7
  KurbanTuruKurbanBayramiKucukbas = 8
  KurbanTuruKurbanBayramiHisseliKurban = 9
  Yurtdisi Kurban = 10
  Talebe Kurban= 11
  Sahis Hiss= 12




  AffinityType_I = 0 Henüz Belli Değil

  AffinityType_I = 1 //İhvan/Ahavat
  AffinityType_M = 2 //Muhibban
  AffinityType_V = 3 //Velî
  AffinityType_MK = 4 //Muhtelif Kominiteler
  AffinityType_P = 5 //Personel



  Origins_T = 1 //turk
  Origins_G = 2 //Gayr-ı Türk


  SELECT * FROM ua_sacrifice_contacts  WHERE  ((id = 3183)) LIMIT 1;
SELECT * FROM ua_sacrifice_list  WHERE contacts_id=3183 ORDER BY id ASC;
SELECT * FROM ua_sacrifice_accounting  WHERE  sacrifice_id IN (5247,5248,5249) ORDER BY id ASC;


  <pre>
  <?php
  global $wpdb;

  // // capitalize first and last name with php
// $sql = 'SELECT id,adi_soyadi from   kurbanlik_bilgileri  '  ;
// $list = $wpdb->get_results($sql);  
// foreach ($list as $row) : 
// echo $name= ucwords(strtolower($row->adi_soyadi)); 
// echo "<br>";
//   $wpdb->update(
//     'kurbanlik_bilgileri',
//       array(
//        'adi_soyadi' =>  $name,

  //      ),
//      array('id' => $row->id)
//      );


//__kurbanlik_bilgileri_500 tablosu icindir 


  $sql = 'SELECT * from   kurbanlik_bilgileri    ';
  $list = $wpdb->get_results($wpdb->prepare($sql));
  foreach ($list as $row):

    echo $sql2 = "SELECT count(id) as count,id,phone,email,origins,affinity_type,user_id from   ua_sacrifice_contacts where  `name_lastname` LIKE '%$row->adi_soyadi%'  GROUP BY id";//bununla kac adet olduklarini bulduk 
    echo "<br>";
    $map = $wpdb->get_row($wpdb->prepare($sql2));
    // echo  $sql2="SELECT count(id) as count  from sacrifice_contacts where  `name_lastname` LIKE '%$row->donor_name $row->donor_lastname%' ";//bununla kac adet olduklarini bulduk 
// echo $more=$wpdb->get_var ($sql2); 
    $more2 = intval($map->count);
    $mip = $map->id;




    if ($more2 > 0) {
      echo "<br>-----girer update--------<br> ";
      print_r($map);

      if ($map->origins == '') {
        $wpdb->update(
          'ua_sacrifice_contacts',
          array(
            'origins' => orign_tip($row->origins),
          ),
          array('id' => $mip)
        );
      }

      if ($map->user_id == '') {
        $wpdb->update(
          'ua_sacrifice_contacts',
          array(
            'user_id' => userID($row->userID),
          ),
          array('id' => $mip)
        );
      }

      if ($map->affinity_type == '') {
        $wpdb->update(
          'ua_sacrifice_contacts',
          array(
            'affinity_type' => affi_tip($row->tip),
          ),
          array('id' => $mip)
        );
      }


      if ($map->phone == '') {
        $wpdb->update(
          'ua_sacrifice_contacts',
          array(
            'phone' => $row->telefon,
          ),
          array('id' => $mip)
        );
      }

      if ($map->email == '') {
        $wpdb->update(
          'ua_sacrifice_contacts',
          array(
            'email' => $row->email,
          ),
          array('id' => $mip)
        );
      }

      $wpdb->insert('ua_sacrifice_list', array(
        'group_id' => 6,
        'user_id' => userID($row->userID),
        'branch_id' => branch($row->sube),
        'contacts_id' => $mip,
        'comments' => "Dikkat bu veri mukerrrer kayit olabilir son 500 adetden otomatik alindi",
        'on_behalf_of_whom' => $row->kim_adina,
        'certificate' => $row->sertifika,
        'attorney_status' => attorney_status($row->vekalet_alindi_mi),
        'weight' => 0,
        'slug' => "u" . getGenarateName(5),
        'sacrifice_type' => 6,
        'status' => 7,
        'debt_status' => 4,
        'group_leader' => 0,
        'sacrifice_price' => 95,
        'cash_debt' => 0,
        'credit' => 0,
        'remaining_balance' => 0,
        'sacrificial_animal_breed' => 1,
        'person_change_lock' => 1,
        'sacrifice_year' => 2022,
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih),
      )
      );



      echo $sql2 = "SELECT id  from ua_sacrifice_list where  id = $wpdb->insert_id ";
      echo $ua_sacrifice_listID = $wpdb->get_var($sql2);

      $wpdb->insert('ua_sacrifice_accounting', array(
        'sacrifice_id' => $ua_sacrifice_listID,
        'user_id' => userID($row->userID),
        'comment' => "ilk Eklenen Fiyat",
        'receipt' => "",
        'staus' => 0,
        'debt_status' => 1,
        'sacrifice_price' => 95,
        'fee_given' => 0,
        'cash_debt' => 0,
        'credit' => 0,
        'remaining_balance' => 95,
        'issued_date' => issuedDate($row->tarih),
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih)
      )
      );

      $wpdb->insert('ua_sacrifice_accounting', array(
        'sacrifice_id' => $ua_sacrifice_listID,
        'user_id' => userID($row->userID),
        'comment' => "Odeme Eklendi: 95 $ / Hesap Kapandi",
        'receipt' => "",
        'staus' => 1,
        'debt_status' => 6,
        'sacrifice_price' => 95,
        'fee_given' => 95,
        'cash_debt' => 0,
        'credit' => 0,
        'remaining_balance' => 95,
        'issued_date' => issuedDate($row->tarih),
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih)
      )
      );



      echo "----MAP ID-------- " . $mip;

      echo "<br>-----girer update sonu --------<br> ";
    } else {




      echo "<br>-----girer insert-------- <br> <br> <br>";
     
      $wpdb->insert('ua_sacrifice_contacts', array(
        'name_lastname' => $row->adi_soyadi,
        'user_id' => userID($row->userID),
        'phone' => $row->telefon,
        'email' => $row->email,
        'status' => 0,
        'reference_user_id' => 0,
        'currency_type' => 2,
        'origins' => orign_tip($row->koken),
        'affinity_type' => affi_tip($row->tip),
        'source_type' => "qurbani500",
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih)
      )
      );

      echo $sql2 = "SELECT id  from ua_sacrifice_contacts where  id = $wpdb->insert_id ";
      echo $ua_sacrifice_listID = $wpdb->get_var($sql2);


      $wpdb->insert('ua_sacrifice_list', array(
        'group_id' => 6,
        'user_id' => userID($row->userID),
        'branch_id' => branch($row->sube),
        'contacts_id' => $wpdb->insert_id,
        'comments' => "Dikkat bu veri mukerrrer kayit olabilir son 500 adetden otomatik alindi",
        'on_behalf_of_whom' => $row->kim_adina,
        'certificate' => $row->sertifika,
        'attorney_status' => attorney_status($row->vekalet_alindi_mi),
        'weight' => 0,
        'slug' => "u" . getGenarateName(5),
        'sacrifice_type' => 6,
        'status' => 7,
        'debt_status' => 4,
        'group_leader' => 0,
        'sacrifice_price' => 95,
        'cash_debt' => 0,
        'credit' => 0,
        'remaining_balance' => 0,
        'sacrificial_animal_breed' => 1,
        'person_change_lock' => 1,
        'sacrifice_year' => 2022,
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih),
      )
      );

  

      $wpdb->insert('ua_sacrifice_accounting', array(
        'sacrifice_id' => $ua_sacrifice_listID,
        'user_id' => userID($row->userID),
        'comment' => "ilk Eklenen Fiyat",
        'receipt' => "",
        'staus' => 0,
        'debt_status' => 1,
        'sacrifice_price' => 95,
        'fee_given' => 0,
        'cash_debt' => 0,
        'credit' => 0,
        'remaining_balance' => 95,
        'issued_date' => issuedDate($row->tarih),
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih)
      )
      );

      $wpdb->insert('ua_sacrifice_accounting', array(
        'sacrifice_id' => $ua_sacrifice_listID,
        'user_id' => userID($row->userID),
        'comment' => "Odeme Eklendi: 95 $ / Hesap Kapandi",
        'receipt' => "",
        'staus' => 1,
        'debt_status' => 6,
        'sacrifice_price' => 95,
        'fee_given' => 95,
        'cash_debt' => 0,
        'credit' => 0,
        'remaining_balance' => 95,
        'issued_date' => issuedDate($row->tarih),
        'created_at' => dateMan($row->tarih),
        'updated_at' => dateMan($row->tarih)
      )
      );

      echo "<br>-----girer insert sonu -------- <br> <br> <br>";


    }










  endforeach;






}
