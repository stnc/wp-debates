<?php
class SLB_Field extends SLB_Field_Type {}
