<?php
$sonuc = '<div class="row recent-events">
<div class="col-md-12">
    <span class="header"> Recent Events</span>
</div>

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz30_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">18</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-30/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 30</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-30/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz29_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">17</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-29/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 29</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-29/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz28_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">16</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-28/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 28</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-28/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz27_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">15</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-27/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 27</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-27/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz26_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">14</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-26/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 26</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-26/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz25_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">13</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-25/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 25</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-25/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz24_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">12</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-23-2/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 24</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-23-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz23_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">11</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-23/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 23</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-23/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz22_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">10</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-22/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 22</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-22/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz20_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">09</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-20-and-21/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : Second half of 20 and 21</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-20-and-21/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz19_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">08</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-19-and-first-half-of-20/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 19 and first half of 20</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-19-and-first-half-of-20/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz18_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">07</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-18/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 18</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-18/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz17_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">06</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">4:30 AM-5:30 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-17/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 17</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;04:30&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-17/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz16_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">05</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-16/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 16</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-16/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz15_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">04</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-15/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 15</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-15/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz14_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">03</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-14/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : 14</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-14/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz12_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">02</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-12-and-13/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ : Second half of 12 and 13</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-12-and-13/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz11_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">01</span>
                <span class="event-date-month">Apr</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-11-and-first-half-of-12/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 11 and first half of 12</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-11-and-first-half-of-12/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz10_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">31</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-10/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 10</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-10/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz9_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">30</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-9/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 9</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-9/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz8_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">29</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-8/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 8</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-8/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz7_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">28</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-7/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 7</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-7/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz6_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">27</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-6/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: 6</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-6/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz4_2.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">26</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-4-and-5-/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ: Second half of 4 and 5 </a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz-second-half-of-4-and-5-/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz3_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">25</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz3-and-first-half-of-4/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:3 and first half of 4</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz3-and-first-half-of-4/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz2_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">24</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz2-2/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:2</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz2-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

<div class="col-lg-4 row xs-single-event">
    <div class="col-md-12">
        <div class="xs-event-image border-gradient border-gradient-turquoise">
            <img src="https://uama.us//d_genel/UAMA_Ramadan_Muqabalah_2022__juz1_1.jpg">
            
            <div class="xs-black-overlay"></div>
        </div><!-- .xs-event-image END -->
        <div class="xs-event-meta-wrapper">
            <div class="xs-event-date">
                <span class="event-date-day">23</span>
                <span class="event-date-month">Mar</span>
            </div>
            <div class="xs-event-clock">
                <span class="xs-event-clock-estimated text-gray">Event Time</span>
                <span class="xs-event-clock-time font-weight-bold text-dark">5:00 AM-6:00 AM (EDT)</span>
            </div>
        </div>
    </div>
    <div class="col-md-12">
        <div class="xs-event-content">
            <a class="xs-event-category badge badge-turquoise text-white p-2 mb-1" href="https://uama.us/en/all-events/muqabalah-2023-ramadan/">Muqabalah 2023 Ramadan</a>
            <h3><a class="text-primary text-dark-blue mb-0" href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz1-2/">The UAMA Online Muqabalah Program (Daily Ramadan Quran Recitation) JUZ:1</a></h3>
            <span class="xs-event-type text-primary text-blue">Online</span>
          
            <p>The "UAMA Online Muqabalah program", which will continue during Ramadan, will be broadcast live every day at&nbsp;05:00&nbsp;(AM) Eastern...</p>
          
            <a href="https://uama.us/en/the-uama-online-muqabalah-program-daily-ramadan-quran-recitation-juz1-2/" class="btn btn-primary btn-narrow bg-dark-blue">
                Learn More
            </a>
        </div><!-- .xs-event-content END -->
    </div>
</div><!-- .xs-single-event END -->

</div>';
