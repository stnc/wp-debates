================================================================================
Important changes and bug fixes in the release v1.5.0 r266  06/08/2022
================================================================================
- Changed:  Since the wordpress "category" is already used, the "Topics" field is opened.
- Bug fix: odemelerde silmede yaşanan sorun vardı düzeltidli 
- Implemented:  air ile çalışılmaya başlandı 

================================================================================
Important changes and bug fixes in the release   V1.0.0  06/02/2024
================================================================================

- Implemented: first version developed