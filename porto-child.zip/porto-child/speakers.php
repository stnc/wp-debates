<?php
/**
 * Template Name: Taxonomy Date Archive.
 *
 */

echo 'spekaers ';

echo '<pre/>';
print_r(get_query_var('list'));
print_r(get_query_var('archive_taxonomy'));
echo '<br>';
print_r(get_query_var('archive_term'));
echo '<br>';
print_r(get_query_var('archive_year'));
echo '<br>';
print_r(get_query_var('archive_month'));


// $id=47; 
// $post = get_post($id); 
// $content = apply_filters('the_content', $post->post_content); 
// echo $content;  

/*
example 1 
echo get_post_meta( get_the_ID(), 'my-info', true );
// You can also call it from the global, as the query refers to the current single page
echo get_post_meta( $GLOBALS['post']->ID, 'my-info', true );

*/


/*
example 2 
  @global / $post
 
 global $post;
$meta = get_post_meta($post->ID,'myinfo-box1', true); 
if ($meta != '') {
    echo $meta;
} else { 
    echo "Can't Display The Content";
} 
 */


$id = get_query_var('list');


$meta = get_post_meta($id, 'tvsDebateMB_speakerList', true);

if ($meta != '') {
    echo $meta;

//[{"speaker":"4136","introduction":" Cultural commentator and broadcaster ","opinions":"1"},{"speaker":"4138","introduction":" Writer, columnist and broadcaster ","opinions":"2"}]

$post = get_post($id); 
$content = apply_filters('the_content', $post->post_content); 

echo $title= the_title();

echo $content;  
//sonra jsondan speaker data ya gidecek 
onlari listele 

} else {
    //    echo "Can't Display The Content";
    wp_redirect("/", 301);
    exit();
}
