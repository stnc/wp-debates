<?php
add_action( 'admin_init', 'uamaWpBranch_Weather_Settings_init' );
$uamaWpBranch_Weather_Settingsoptions = get_option('uamaWpBranch_Weather_Settings');
function uamaWpBranch_Weather_Settings_init(  ) {

    register_setting('uamaWpBranch_WeatherConfig', 'uamaWpBranch_Weather_Settings');

    add_settings_section(
        'uamaWpBranch_Weather_section',
        __( 'Hava Durumu Ayarlari', 'wordpress' ),
        'uamaWpBranch_Weather_Settings_section_callback',
        'uamaWpBranch_WeatherConfig'
    );

    add_settings_field(
        'uamaWpBranch_text_field_weather_date',
        __( 'Tarih', 'wordpress' ),
        'weather_date_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    );


    add_settings_field(
        'uamaWpBranch_text_field_weather_day',
        __( 'Gun', 'wordpress' ),
        'weather_day_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    ); 
    
    // add_settings_field(
    //     'uamaWpBranch_text_field_weather_icon',
    //     __( 'Ikon resmi', 'wordpress' ),
    //     'weather_icon_uamaWpBranch_text_field_render',
    //     'uamaWpBranch_WeatherConfig',
    //     'uamaWpBranch_Weather_section'
    // ); 

    add_settings_field(
        'uamaWpBranch_text_field_weather_description',
        __( 'Hava Durumu', 'wordpress' ),
        'weather_description_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    ); 

    add_settings_field(
        'uamaWpBranch_text_field_weather_description_en',
        __( 'Hava Durumu (ingilizce)', 'wordpress' ),
        'weather_description_en_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    ); 

    add_settings_field(
        'uamaWpBranch_text_field_weather_degree',
        __( 'Derece', 'wordpress' ),
        'weather_degree_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    ); 

    add_settings_field(
        'uamaWpBranch_text_field_weather_night',
        __( 'Gece Sicakligi', 'wordpress' ),
        'weather_night_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    );   
    
    add_settings_field(
        'uamaWpBranch_text_field_weather_humidity',
        __( 'Nem Orani', 'wordpress' ),
        'weather_humidity_uamaWpBranch_text_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    ); 

    add_settings_field(
        'uamaWpBranch_Weather_Today',
        __( '7 Günlük Hava Bilgisi ', 'wordpress' ),
        'weather_humidity_uamaWpBranch_read_field_render',
        'uamaWpBranch_WeatherConfig',
        'uamaWpBranch_Weather_section'
    ); 

}

function weather_day_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
    $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_day]' value='<?php   print (isset($options['uamaWpBranch_text_field_weather_day'])) ? $options['uamaWpBranch_text_field_weather_day'] : "";?>'>
    <small>Kullanimda degildir  bilgi amaclidir</small>
  <?php
}


function weather_date_uamaWpBranch_text_field_render(  ) {
   global  $uamaWpBranch_Weather_Settingsoptions;
   $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_date]' value='<?php print (isset($options['uamaWpBranch_text_field_weather_date'])) ? $options['uamaWpBranch_text_field_weather_date'] : "";?>'>
    <small>Kullanimda degildir  bilgi amaclidir</small>
    <?php
}

function weather_icon_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
    $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_icon]' value='<?php print (isset($options['uamaWpBranch_text_field_weather_icon'])) ? $options['uamaWpBranch_text_field_weather_icon'] : ""; ?>'>
  <?php if ($options['uamaWpBranch_text_field_weather_icon']!="" && isset($options['uamaWpBranch_text_field_weather_icon'])):
    ?>
    <img src="<?php print (isset($options['uamaWpBranch_text_field_weather_icon'])) ? $options['uamaWpBranch_text_field_weather_icon'] : "";  ?>" alt="" style="width: 85px; height: 100px;">
    <?php
      endif;
}
function weather_description_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
    $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_description]' 
    value='<?php print (isset($options['uamaWpBranch_text_field_weather_description'])) ? $options['uamaWpBranch_text_field_weather_description'] : ""; ?>'>
    <?php
}

function weather_description_en_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
    $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_description_en]' 
    value='<?php print (isset($options['uamaWpBranch_text_field_weather_description_en'])) ? $options['uamaWpBranch_text_field_weather_description_en'] : "";  ?>'>
    <small>Kullanimda degildir  bilgi amaclidir</small>
    <?php
}
function weather_degree_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
    $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_degree]' 
    value='<?php print (isset($options['uamaWpBranch_text_field_weather_degree'])) ? $options['uamaWpBranch_text_field_weather_degree'] : "";  ?>'>
    <?php
}

function weather_night_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
   $options = $uamaWpBranch_Weather_Settingsoptions;
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_night]' 
    value='<?php  print (isset($options['uamaWpBranch_text_field_weather_night'])) ? $options['uamaWpBranch_text_field_weather_night'] : ""; ?>'>
    <?php
}

function weather_humidity_uamaWpBranch_text_field_render(  ) {
    global  $uamaWpBranch_Weather_Settingsoptions;
    $options = $uamaWpBranch_Weather_Settingsoptions;
    
    ?>
    <input type='text' name='uamaWpBranch_Weather_Settings[uamaWpBranch_text_field_weather_humidity]' 
    value='<?php print (isset($options['uamaWpBranch_text_field_weather_humidity'])) ? $options['uamaWpBranch_text_field_weather_humidity'] : "";  ?>'>
    <?php
}


function weather_humidity_uamaWpBranch_read_field_render(  ) {
    $optionsWeather6Today = get_option('uamaWpBranch_Weather_Today');
  //  $weather6Today = json_decode($optionsWeather6Today, true);
    ?>
<textarea rows="4" cols="50">
<?php echo $optionsWeather6Today; ?>
</textarea>
<small>kaydetmek için değildir,  bilgi amaclidir</small>
    <?php
}

function uamaWpBranch_Weather_Settings_section_callback(  ) {
    //echo __( 'bu konuda ayrintili bilgi icin bu sayfaya bakiniz ', 'wordpress' );
}

function uamaWpBranch_config_weather(  ) {
    ?>
    <form action='options.php' method='post'>
        <?php
        settings_fields( 'uamaWpBranch_WeatherConfig' );
        do_settings_sections( 'uamaWpBranch_WeatherConfig' );
        submit_button();
        ?>
    </form>
    <?php
}