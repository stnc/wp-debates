<?php exit; ?>
[2024-10-02 23:11:39] ERROR: Form 5611 > Mailchimp API error: 403 Forbidden. User Disabled. This account has been deactivated.

Request: 
GET https://us11.api.mailchimp.com/3.0/lists/d9f881de8f/members/4e57a2f7316d837a4efd31798279365c


Response: 
403 Forbidden
{"type":"https://mailchimp.com/developer/marketing/docs/errors/","title":"User Disabled","status":403,"detail":"This account has been deactivated.","instance":"cda7b652-c522-ec17-a90c-59e6890441c4"}
