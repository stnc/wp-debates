<?php
function uama_wp_branch_about()
{


  if (!current_user_can('manage_options')) {
    return;
  }


  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1> Ekranlar Bilinmesi Gerekenler</h1>
    <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;">



      <strong>Eklentinin Kullanımı</strong>


    </div>

  </div>
<pre>
<?php
global $wpdb;

// // capitalize first and last name with php
// $sql = 'SELECT id,ad_soyad from   sacrifice_kisiler  '  ;
// $list = $wpdb->get_results($sql);  
// foreach ($list as $row) : 
// echo $name= ucwords(strtolower($row->ad_soyad)); 
// echo "<br>";
//   $wpdb->update(
//     'sacrifice_contacts',
//       array(
//        'ad_soyad' =>  $name,
    
//      ),
//      array('id' => $row->id)
//      );





// $sql = 'SELECT * from   ua_bagislar  where contacts_id=0  '  ;
// $list = $wpdb->get_results($wpdb->prepare($sql));    
// foreach ($list as $row) : 

// echo  $sql2="SELECT count(id) as count,id,phone,email from   sacrifice_contacts where  `name_lastname` LIKE '%$row->donor_name $row->donor_lastname%'  GROUP BY id";//bununla kac adet olduklarini bulduk 
// echo "<br>";
// $map = $wpdb->get_row($wpdb->prepare($sql2));
// // echo  $sql2="SELECT count(id) as count  from sacrifice_contacts where  `name_lastname` LIKE '%$row->donor_name $row->donor_lastname%' ";//bununla kac adet olduklarini bulduk 
// // echo $more=$wpdb->get_var ($sql2); 
// $more2=intval($map->id);
// $mip=$map->id;
// if ($more2 > 0){
// echo "<br>-----girer update--------<br> ";
// // print_r($map );
//   $wpdb->update(
//     'sacrifice_contacts',
//       array(
//        'name' => $row->donor_name,
//        'lastname' => $row->donor_lastname,
//        'city' => $row->city,
//        'country' => $row->country,
//        'adress1' => $row->adress1,
//        'adress2' => $row->adress2,
//        'zip_code' => $row->zip_code,
//        'state' => $row->state,
//        'comment' => "Phone:".$row->phone.","."Email:".$row->email,
//        'added' => 1
//      ),
//      array('id' => $mip)
//      );

// if ($map->phone==''){
//   $wpdb->update(
//     'sacrifice_contacts',
//       array(
//        'phone' => $row->phone,
//      ),
//      array('id' => $mip)
//      );

// }

// if ($map->email==''){
//   $wpdb->update(
//     'sacrifice_contacts',
//       array(
//        'email' => $row->email,
//      ),
//      array('id' =>$mip)
//      );
//  }


//      $wpdb->update(
//       'ua_bagislar',
//         array(
//          'contacts_id' =>$mip,
//        ),
//        array('id' => $row->id)
//        );


//        echo "----MAP ID-------- ".$mip;

// echo "<br>-----girer update sonu --------<br> ";
// } 

// else {

//   echo "<br>-----girer insert-------- <br> <br> <br>";
//   print_r($map );
//   $wpdb->insert('sacrifice_contacts', array(
//     'name_lastname' => $row->donor_name." ".$row->donor_lastname,
//     'name' => $row->donor_name,
//     'lastname' => $row->donor_lastname,
//     'phone' => $row->phone,
//     'email' => $row->email,
//     'city' => $row->city,
//     'country' => $row->country,
//     'adress1' => $row->adress1,
//     'adress2' => $row->adress2,
//     'zip_code' => $row->zip_code,
//     'state' => $row->state,
//     'added' => 0,
    
//     'user_type' => "donate",
//   ));



//   $wpdb->update(
//     'ua_bagislar',
//       array(
//        'contacts_id' => $wpdb->insert_id,
//      ),
//      array('id' => $row->id)
//      );
  
//      echo "<br>-----girer insert sonu -------- <br> <br> <br>";
  
  
// }











/// bu kisimlar duplicate kurban ve kisileri merge etmek icin V 0.1 

// This section is for duplicate finding  sacrife and people and merge


// $sql="SELECT id from   sacrifice_kisiler where id != match_id ";
//  echo "<br>";

//  $map = $wpdb->get_results($wpdb->prepare($sql));




  // $wpdb->update(
  //  'sacrifice_kurbanlar',
  //    array(
  //       'kisi_id' =>  $kisi->match_id,
  //   ),
  //   array('kisi_id' => $kisi->id)
  //   );




// $sql="SELECT id from   sacrifice_kisiler where  `ad_soyad` LIKE '%$kisi->ad_soyad%' ";
//  echo "<br>";

//  $map = $wpdb->get_results($wpdb->prepare($sql));

// echo $map[0]->id;

//   $wpdb->update(
//   'sacrifice_kisiler',
//     array(
//         'match_id' =>  $map[0]->id,
//     ),
//     array('id' =>$kisi->id )
//     );

//  print_r( $map);
//  $sql="SELECT count(id) from   sacrifice_kisiler where  `ad_soyad` LIKE '%$kisi->ad_soyad%' ";//bununla kac adet olduklarini bulduk 
// echo $more=$wpdb->get_var ($sql); //bununla kac adet olduklarini bulduk 
// if ( $more >1 ){
//   $wpdb->update(
//   'sacrifice_kisiler',
//     array(
//         'is_more' =>  1,
//     ),
//     array('id' =>$kisi->id )
//     );
// }



 endforeach ;






}
