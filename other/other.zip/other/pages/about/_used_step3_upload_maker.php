<?php
function uama_wp_branch_about()
{


  if (!current_user_can('manage_options')) {
    return;
  }


  ?>
  <!-- Our admin page content should all be inside .wrap -->
  <div class="wrap">
    <!-- Print the page title -->
    <h1> Ekranlar Bilinmesi Gerekenler</h1>
    <div style="background: #fff;
    border: 1px solid #c3c4c7;
    border-left-width: 4px;
    box-shadow: 0 1px 1px rgb(0 0 0 / 4%);
    margin: 5px 5px 2px;
    padding: 1px 12px;">



      <strong>Eklentinin Kullanımı</strong>


    </div>
  </div>
  <?php



  //https://code.tutsplus.com/writing-custom-queries-in-wordpress--wp-25510t

  global $wpdb;

  // $current_user = wp_get_current_user();

  // $uid = $current_user->ID;

  // $fname = $current_user->first_name . " " . $current_user->last_name;

  // $email = $current_user->user_email;

  // $studentTable = $wpdb->prefix.'um_metadata';

  // $sql = 'SELECT * FROM user2'  ;
// $buildingsList = $wpdb->get_results($sql);    
// foreach ($buildingsList as $building) : 
//     echo $building->first_name ;
//     echo '<br>';

  //     $post_id = wp_insert_post(array (
//       'post_type' => 'uama_staff',
//       'post_title' => $building->first_name." ".$building->last_name,
//       'post_content' => "Staff Info",
//       'post_status' => 'publish',
//       'visibility' => 'provate',
//       'comment_status' => 'closed',
//       'ping_status' => 'closed',
//       'meta_input' => array(
//          'uama_wp_staff_Metabox_email' => $building->email,
//          'uama_wp_staff_Metabox_name_lastname' =>  $building->first_name." ".$building->last_name,
//          'uama_wp_staff_Metabox_name' =>  $building->first_name,
//          'uama_wp_staff_Metabox_lastname' =>  $building->last_name,
//          'uama_wp_staff_Metabox_password' =>  $building->password,
//          'uama_wp_staff_Metabox_phone1' =>  $building->phone,
//          'uama_wp_staff_Metabox_username' =>  $building-> username ,
//          'uama_wp_staff_Metabox_website' =>  "",
//        ),
//    ));
//  endforeach ;

  // die;









 include ("_data_events.php");






  // $sql = 'SELECT * FROM aktar_blog_list where durum=0 limit 1;';
  $sql = 'SELECT * FROM event_data where resim_indimi=0 limit 10';
  $content = $wpdb->get_results($sql);
  foreach ($content as $key => $value):

    // $sonuc = curll($value->sayfa);
    // $page = regexPage($sonuc)[0];
    // $title = regexTitle($sonuc)[0];

   echo  $wp_media_id = rudr_upload_file_by_url($value->resim);
   echo '<pre>';

     $wpdb->update(
         'event_data',
        array(
             'resim_indimi' =>  1,
             'wp_media_id' =>   $wp_media_id,
        ),
        array('id' =>$value->id )
        );



  endforeach;




}


function curll($sayfa)
{
  $ch = curl_init();

  curl_setopt($ch, CURLOPT_URL, $sayfa);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  $sonuc = curl_exec($ch);

  curl_close($ch);
  return $sonuc;
}



/**
* Upload image from URL programmatically
*
* @author Misha Rudrastyh
* @link https://rudrastyh.com/wordpress/how-to-add-images-to-media-library-from-uploaded-files-programmatically.html#upload-image-from-url
*/
function rudr_upload_file_by_url( $image_url ) {

  // it allows us to use download_url() and wp_handle_sideload() functions
  require_once( ABSPATH . 'wp-admin/includes/file.php' );
  
  // download to temp dir
  
  $temp_file = download_url( $image_url );
  
  if( is_wp_error( $temp_file ) ) {
  return false;
  }
  
  // move the temp file into the uploads directory
  $file = array(
  'name'     => basename( $image_url ),
  'type'     => mime_content_type( $temp_file ),
  'tmp_name' => $temp_file,
  'size'     => filesize( $temp_file ),
  );
  $sideload = wp_handle_sideload(
  $file,
  array(
  'test_form'   => false // no needs to check 'action' parameter
  )
  );
  
  if( ! empty( $sideload[ 'error' ] ) ) {
  // you may return error message if you want
  return false;
  }
  
  // it is time to add our uploaded image into WordPress media library
  $attachment_id = wp_insert_attachment(
  array(
  'guid'           => $sideload[ 'url' ],
  'post_mime_type' => $sideload[ 'type' ],
  'post_title'     => basename( $sideload[ 'file' ] ),
  'post_content'   => '',
  'post_status'    => 'inherit',
  ),
  $sideload[ 'file' ]
  );
  
  if( is_wp_error( $attachment_id ) || ! $attachment_id ) {
  return false;
  }
  
  // update metadata, regenerate image sizes
  require_once( ABSPATH . 'wp-admin/includes/image.php' );
  
  wp_update_attachment_metadata(
  $attachment_id,
  wp_generate_attachment_metadata( $attachment_id, $sideload[ 'file' ] )
  );
  
  return $attachment_id;
  }


  //verilen linkdeki resimi indirir
function download_image1($image_url, $image_file)
{
    $fp = fopen($image_file, 'w+'); // open file handle
    $ch = curl_init($image_url);
    // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // enable if you want
    curl_setopt($ch, CURLOPT_FILE, $fp); // output to file
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 1000); // some large value to allow curl to run for a long time
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    // curl_setopt($ch, CURLOPT_VERBOSE, true);   // Enable this line to see debug prints
    curl_exec($ch);

    curl_close($ch); // closing curl handle
    fclose($fp); // closing file handle

}