<?php
add_action( 'admin_init', 'uamaWpBranch_Exchange_Settings_init' );

function uamaWpBranch_Exchange_Settings_init(  ) {
    register_setting( 'uamaWpBranch_ExchangeConfig', 'uamaWpBranch_Exchange_Settings' );
    add_settings_section(
        'uamaWpBranch_Exchange_section',
        __( 'Doviz Altin Ayarlari', 'wordpress' ),
        'uamaWpBranch_Exchange_Settings_section_callback',
        'uamaWpBranch_ExchangeConfig'
    );

    add_settings_field(
        'uamaWpBranch_text_field_dolar',
        __( 'Dolar', 'wordpress' ),
        'dolar_uamaWpBranch_text_field_render',
        'uamaWpBranch_ExchangeConfig',
        'uamaWpBranch_Exchange_section'
    );



    add_settings_field(
        'uamaWpBranch_text_field_euro',
        __( 'Euro', 'wordpress' ),
        'euro_uamaWpBranch_text_field_render',
        'uamaWpBranch_ExchangeConfig',
        'uamaWpBranch_Exchange_section'
    );

    add_settings_field(
        'uamaWpBranch_text_field_altin',
        __( 'Altin', 'wordpress' ),
        'altin_uamaWpBranch_text_field_render',
        'uamaWpBranch_ExchangeConfig',
        'uamaWpBranch_Exchange_section'
    );
    add_settings_field(
        'uamaWpBranch_text_field_ceyrek_altin',
        __( 'Ceyrek Altin', 'wordpress' ),
        'ceyrek_altin_uamaWpBranch_text_field_render',
        'uamaWpBranch_ExchangeConfig',
        'uamaWpBranch_Exchange_section'
    );



    
}

function dolar_uamaWpBranch_text_field_render(  ) {
    $options = get_option( 'uamaWpBranch_Exchange_Settings' );
    ?>
    <input type='text' name='uamaWpBranch_Exchange_Settings[uamaWpBranch_text_field_dolar]' value='<?php  print (isset($options['uamaWpBranch_text_field_dolar'])) ? $options['uamaWpBranch_text_field_dolar'] : "";  ?>'>
    <?php
}


function euro_uamaWpBranch_text_field_render(  ) {
    $options = get_option( 'uamaWpBranch_Exchange_Settings' );
    ?>
    <input type='text' name='uamaWpBranch_Exchange_Settings[uamaWpBranch_text_field_euro]' value='<?php  print (isset($options['uamaWpBranch_text_field_euro'])) ? $options['uamaWpBranch_text_field_euro'] : ""; ?>'>
    <?php
}

function altin_uamaWpBranch_text_field_render(  ) {
    $options = get_option( 'uamaWpBranch_Exchange_Settings' );
    ?>
    <input type='text' name='uamaWpBranch_Exchange_Settings[uamaWpBranch_text_field_altin]' value='<?php  print (isset($options['uamaWpBranch_text_field_altin'])) ? $options['uamaWpBranch_text_field_altin'] : "";  ?>'>
    <?php
}
function ceyrek_altin_uamaWpBranch_text_field_render(  ) {
    $options = get_option( 'uamaWpBranch_Exchange_Settings' );
    ?>
    <input type='text' name='uamaWpBranch_Exchange_Settings[uamaWpBranch_text_field_ceyrek_altin]' value='<?php print (isset($options['uamaWpBranch_text_field_ceyrek_altin'])) ? $options['uamaWpBranch_text_field_ceyrek_altin'] : ""; ?>'>
    <?php
}





function uamaWpBranch_Exchange_Settings_section_callback(  ) {
    echo __( 'bu konuda ayrintili bilgi icin bu sayfaya bakiniz ', 'wordpress' );
}

function uamaWpBranch_config_exchange(  ) {
    ?>
    <form action='options.php' method='post'>
        <?php
        settings_fields( 'uamaWpBranch_ExchangeConfig' );
        do_settings_sections( 'uamaWpBranch_ExchangeConfig' );
        submit_button();
        ?>
    </form>
    <?php
}